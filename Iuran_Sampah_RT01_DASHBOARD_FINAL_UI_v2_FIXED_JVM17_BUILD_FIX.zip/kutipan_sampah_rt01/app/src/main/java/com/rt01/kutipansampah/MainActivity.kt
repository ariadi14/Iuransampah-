package com.rt01.kutipansampah

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

private val Green = Color(0xFF087F5B)
private val DarkGreen = Color(0xFF14532D)
private val LightGreen = Color(0xFFEAF8F2)
private val PaleGreen = Color(0xFFF4FBF7)
private val Orange = Color(0xFFF59F00)
private val Red = Color(0xFFE03131)
private val Blue = Color(0xFF1971C2)
private val Ink = Color(0xFF18201C)
private val Muted = Color(0xFF718078)

private fun rupiah(v: Int): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }.format(v)
private fun todayLabel(): String = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(Date()).replaceFirstChar { it.uppercase() }

data class Resident(val name: String, val house: String, val phone: String, val paid: Int, val due: Int)
enum class Tab { DASHBOARD, WARGA, BAYAR, LAPORAN, LAINNYA }
enum class Status { LUNAS, KURANG, BELUM }

data class NavState(
    val tab: Tab = Tab.DASHBOARD,
    val resident: Resident? = null,
    val payment: Boolean = false,
    val paymentFilter: Status? = null,
    val report: Boolean = false,
    val reminder: Boolean = false,
    val password: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KutipanApp(this) }
    }
}

@Composable
fun KutipanApp(context: Context) {
    var loggedIn by remember { mutableStateOf(false) }
    if (!loggedIn) LoginScreen { loggedIn = true } else MainShell(context) { loggedIn = false }
}

@Composable
fun BrandHeader(compact: Boolean = false, title: String = "Iuran Sampah") {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = if (compact) 10.dp else 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(if (compact) 40.dp else 48.dp).clip(RoundedCornerShape(14.dp)).background(LightGreen), contentAlignment = Alignment.Center) {
            Text("♻", fontSize = if (compact) 25.sp else 29.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = if (compact) 19.sp else 21.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text("RT 01", fontSize = if (compact) 16.sp else 18.sp, fontWeight = FontWeight.ExtraBold, color = Green)
            if (!compact) Text("Bersih Lingkungan, Sehat Bersama", color = Green, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun ScreenTop(title: String, back: (() -> Unit)? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) {
            Text("‹", fontSize = 32.sp, color = Ink, modifier = Modifier.size(38.dp).clickable { back() }, textAlign = TextAlign.Center)
        } else Spacer(Modifier.width(38.dp))
        Text(title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Ink, textAlign = TextAlign.Center)
        if (trailing != null) trailing() else Spacer(Modifier.width(38.dp))
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(PaleGreen)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(32.dp))
            Box(Modifier.size(210.dp).clip(RoundedCornerShape(44.dp)).background(LightGreen), contentAlignment = Alignment.Center) {
                Text("♻", fontSize = 108.sp)
            }
            Text("Iuran Sampah", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(top = 12.dp))
            Text("RT 01", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Green)
            Text("Lingkungan Bersih\nWarga Sehat", color = Green, textAlign = TextAlign.Center, fontSize = 14.sp, modifier = Modifier.padding(top = 5.dp))
            Spacer(Modifier.height(24.dp))
            Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(user, { user = it; error = false }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(pass, { pass = it; error = false }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = rememberMe, onCheckedChange = { rememberMe = it })
                        Text("Ingat saya", color = Muted)
                    }
                    if (error) Text("Username atau password salah.", color = Red, fontSize = 12.sp)
                    Button(onClick = { if (user == "admin" && pass == "admin123") onLogin() else error = true }, Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(13.dp)) { Text("LOGIN", fontWeight = FontWeight.ExtraBold) }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("“Bersama kita jaga lingkungan yang bersih”", color = DarkGreen, fontSize = 13.sp)
            Spacer(Modifier.height(22.dp))
        }
    }
}

@Composable
fun MainShell(context: Context, logout: () -> Unit) {
    val month = remember { SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date()).replaceFirstChar { it.uppercase() } }
    var nav by remember { mutableStateOf(NavState()) }
    var residents by remember { mutableStateOf(emptyList<Resident>()) }

    fun go(tab: Tab) { nav = NavState(tab = tab) }
    fun openPayment(filter: Status?) { nav = NavState(tab = Tab.BAYAR, paymentFilter = filter) }

    when {
        nav.password -> PasswordScreen(onBack = { nav = NavState(Tab.LAINNYA) })
        nav.reminder -> ReminderScreen(residents, onBack = { nav = NavState(Tab.LAINNYA) }, onOpenUnpaid = { go(Tab.BAYAR) })
        nav.resident != null -> DetailResident(nav.resident!!, onBack = { nav = NavState(Tab.WARGA) })
        nav.payment -> PaymentScreen(residents, onBack = { nav = NavState(Tab.BAYAR, paymentFilter = nav.paymentFilter) }, onSave = { name, amount -> residents = residents.map { if (it.name == name) it.copy(paid = amount.coerceAtMost(it.due)) else it }; nav = NavState(Tab.BAYAR, paymentFilter = nav.paymentFilter) })
        else -> Scaffold(bottomBar = { BottomNav(nav.tab) { go(it) } }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().background(PaleGreen)) {
                when (nav.tab) {
                    Tab.DASHBOARD -> Dashboard(
                        residents = residents,
                        onOpenResidents = { go(Tab.WARGA) },
                        onOpenPayment = { openPayment(it) },
                        onOpenReport = { go(Tab.LAPORAN) },
                        onResident = { nav = nav.copy(resident = it) },
                        onPay = { nav = nav.copy(payment = true) }
                    )
                    Tab.WARGA -> ResidentsScreen(residents, onResident = { nav = nav.copy(resident = it) }, onAdd = { residents = residents + Resident("Warga Baru", "Rumah ${residents.size + 1}", "", 0, 10000) })
                    Tab.BAYAR -> PaymentOverview(residents, filter = nav.paymentFilter, onFilter = { openPayment(it) }, onPay = { nav = nav.copy(payment = true) })
                    Tab.LAPORAN -> ReportScreen(month, residents, context)
                    Tab.LAINNYA -> MoreScreen(onReminder = { nav = nav.copy(reminder = true) }, onPassword = { nav = nav.copy(password = true) }, logout = logout)
                }
            }
        }
    }
}

@Composable
fun Dashboard(
    residents: List<Resident>,
    onOpenResidents: () -> Unit,
    onOpenPayment: (Status) -> Unit,
    onOpenReport: () -> Unit,
    onResident: (Resident) -> Unit,
    onPay: () -> Unit
) {
    val paid = residents.count { it.paid >= it.due && it.due > 0 }
    val unpaid = residents.count { it.paid == 0 }
    val income = residents.sumOf { it.paid }
    var currentTime by remember { mutableStateOf(SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())) }
    var currentDate by remember { mutableStateOf(todayLabel()) }
    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTime = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(now)
            currentDate = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(now).replaceFirstChar { it.uppercase() }
            delay(1000)
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(PaleGreen)) {
        Box(Modifier.fillMaxWidth().height(138.dp)) {
            Image(
                painter = painterResource(com.rt01.kutipansampah.R.drawable.dashboard_header),
                contentDescription = "Header Iuran Sampah RT 01",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(currentTime, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen)
                Text(currentDate, fontSize = 15.sp, color = Muted, fontWeight = FontWeight.SemiBold)
            }
        }

        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp).clickable { onOpenReport() },
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(Color(0xFF3FBE78)),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(CircleShape).background(Color.White.copy(alpha = .35f)), contentAlignment = Alignment.Center) { Text("▤", fontSize = 30.sp, color = Color.White) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Laporan", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text("Total Pemasukan dari Warga", fontSize = 13.sp, color = Color.White)
                    Text(rupiah(income), fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                }
                Text("›", fontSize = 38.sp, color = Color.White, fontWeight = FontWeight.Light)
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("✓", "Sudah Bayar", paid.toString(), Green, Modifier.weight(1f)) { onOpenPayment(Status.LUNAS) }
            StatCard("👥", "Total Warga", residents.size.toString(), Blue, Modifier.weight(1f)) { onOpenResidents() }
            StatCard("×", "Belum Bayar", unpaid.toString(), Red, Modifier.weight(1f)) { onOpenPayment(Status.BELUM) }
        }

        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
            Column(Modifier.padding(vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Daftar Terbaru", modifier = Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Ink)
                    Text("Lihat Semua", color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.clickable { onOpenResidents() })
                }
                if (residents.isEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Belum ada data warga", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                        Text("Tambahkan warga melalui menu Warga.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                } else {
                    residents.sortedBy { it.name }.take(5).forEach { ResidentRow(it, onResident, showStatus = true) }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
fun StatCard(icon: String, label: String, value: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 13.dp, horizontal = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(45.dp).clip(CircleShape).background(color.copy(alpha = .12f)), contentAlignment = Alignment.Center) { Text(icon, fontSize = 22.sp, color = color, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize = 10.sp, color = Ink, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text("Warga", fontSize = 10.sp, color = Muted)
        }
    }
}

@Composable
fun ResidentsScreen(residents: List<Resident>, onResident: (Resident) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader(compact = true)
        ScreenTop("Data Warga", trailing = { Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(Green), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp), shape = RoundedCornerShape(12.dp)) { Text("+") } })
        var query by remember { mutableStateOf("") }
        OutlinedTextField(query, { query = it }, placeholder = { Text("Cari nama atau nomor rumah...") }, leadingIcon = { Text("⌕", fontSize = 22.sp) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true, shape = RoundedCornerShape(13.dp))
        val filtered = residents.filter { it.name.contains(query, true) || it.house.contains(query, true) }.sortedBy { it.name }
        LazyColumn(Modifier.padding(top = 8.dp)) { items(filtered) { ResidentRow(it, onResident, showStatus = true) } }
    }
}

@Composable
fun ResidentRow(r: Resident, onClick: (Resident) -> Unit, showStatus: Boolean = true) {
    val status = when { r.paid >= r.due -> Status.LUNAS; r.paid > 0 -> Status.KURANG; else -> Status.BELUM }
    val color = when (status) { Status.LUNAS -> Green; Status.KURANG -> Orange; Status.BELUM -> Red }
    val label = when (status) { Status.LUNAS -> "Lunas"; Status.KURANG -> "Kurang Bayar"; Status.BELUM -> "Belum Bayar" }
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clickable { onClick(r) }, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(Color.White)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(color.copy(alpha = .12f)), contentAlignment = Alignment.Center) { Text("●", fontSize = 25.sp, color = color) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.Bold, color = Ink); Text(r.house, fontSize = 12.sp, color = Muted); if (r.phone.isNotBlank()) Text(r.phone, fontSize = 11.sp, color = Muted) }
            if (showStatus) Surface(color = color.copy(alpha = .13f), shape = RoundedCornerShape(10.dp)) { Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) }
        }
    }
}

@Composable
fun PaymentOverview(residents: List<Resident>, filter: Status?, onFilter: (Status?) -> Unit, onPay: () -> Unit) {
    val filtered = residents.filter {
        when (filter) {
            Status.LUNAS -> it.paid >= it.due && it.due > 0
            Status.KURANG -> it.paid in 1 until it.due
            Status.BELUM -> it.paid == 0
            null -> true
        }
    }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().background(PaleGreen)) {
        BrandHeader(compact = true, title = "Iuran Sampah")
        ScreenTop("Pencatatan Pembayaran", trailing = { Button(onClick = onPay, colors = ButtonDefaults.buttonColors(Green), contentPadding = PaddingValues(horizontal = 11.dp), shape = RoundedCornerShape(11.dp)) { Text("+") } })
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = filter == null, onClick = { onFilter(null) }, label = { Text("Semua") })
            FilterChip(selected = filter == Status.LUNAS, onClick = { onFilter(Status.LUNAS) }, label = { Text("Lunas") })
            FilterChip(selected = filter == Status.BELUM, onClick = { onFilter(Status.BELUM) }, label = { Text("Belum Bayar") })
            FilterChip(selected = filter == Status.KURANG, onClick = { onFilter(Status.KURANG) }, label = { Text("Kurang") })
        }
        Button(onClick = onPay, Modifier.fillMaxWidth().padding(16.dp).height(46.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(13.dp)) { Text("CATAT PEMBAYARAN", fontWeight = FontWeight.Bold) }
        if (filtered.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (residents.isEmpty()) "Belum ada data warga" else "Tidak ada warga dengan status ini", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                Text("Data pembayaran akan tampil setelah warga ditambahkan.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
            }
        } else {
            LazyColumn { items(filtered) { ResidentRow(it, { onPay() }, showStatus = true) } }
        }
    }
}

@Composable
fun PaymentScreen(residents: List<Resident>, onBack: () -> Unit, onSave: (String, Int) -> Unit) {
    var selected by remember { mutableStateOf(residents.firstOrNull()) }
    var amount by remember { mutableStateOf("5000") }
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(PaleGreen)) {
        BrandHeader(compact = true)
        ScreenTop("Pencatatan Pembayaran", onBack)
        Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("Pilih Warga", fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp))
                Box { OutlinedButton(onClick = { expanded = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(11.dp)) { Text(selected?.name ?: "Pilih warga", Modifier.weight(1f), textAlign = TextAlign.Start); Text("⌄") }; DropdownMenu(expanded, { expanded = false }) { residents.forEach { r -> DropdownMenuItem(text = { Text("${r.name} • ${r.house}") }, onClick = { selected = r; expanded = false }) } } }
                Spacer(Modifier.height(14.dp)); Text("Bulan", fontWeight = FontWeight.Bold); OutlinedTextField("September 2026", {}, Modifier.fillMaxWidth(), enabled = false, shape = RoundedCornerShape(11.dp))
                Spacer(Modifier.height(14.dp)); Text("Nominal Iuran", fontWeight = FontWeight.Bold); OutlinedTextField(rupiah(selected?.due ?: 10000), {}, Modifier.fillMaxWidth(), enabled = false, shape = RoundedCornerShape(11.dp))
                Spacer(Modifier.height(12.dp)); Text("Jumlah Bayar", fontWeight = FontWeight.Bold); OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), singleLine = true, prefix = { Text("Rp ") }, shape = RoundedCornerShape(11.dp))
                Spacer(Modifier.height(14.dp)); val due = selected?.due ?: 10000; val paid = amount.toIntOrNull() ?: 0; val status = if (paid >= due) Status.LUNAS else if (paid > 0) Status.KURANG else Status.BELUM
                Text("Status", fontWeight = FontWeight.Bold); Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) { StatusButton("Lunas", Status.LUNAS, status, Modifier.weight(1f)); Spacer(Modifier.width(6.dp)); StatusButton("Kurang Bayar", Status.KURANG, status, Modifier.weight(1f)); Spacer(Modifier.width(6.dp)); StatusButton("Belum Bayar", Status.BELUM, status, Modifier.weight(1f)) }
                Surface(color = when(status) { Status.LUNAS -> LightGreen; Status.KURANG -> Color(0xFFFFF3D6); Status.BELUM -> Color(0xFFFFE5E5) }, shape = RoundedCornerShape(11.dp), modifier = Modifier.fillMaxWidth()) { Text(if (status == Status.LUNAS) "Pembayaran lunas" else if (status == Status.KURANG) "Sisa: ${rupiah(due - paid)}" else "Belum ada pembayaran", modifier = Modifier.padding(14.dp), color = when(status) { Status.LUNAS -> Green; Status.KURANG -> Orange; Status.BELUM -> Red }, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(16.dp)); OutlinedTextField("Bayar sebagian", {}, Modifier.fillMaxWidth(), label = { Text("Catatan (opsional)") }, minLines = 2, shape = RoundedCornerShape(11.dp))
                Spacer(Modifier.height(16.dp)); Button(onClick = { selected?.let { onSave(it.name, paid) } }, Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(13.dp)) { Text("SIMPAN PEMBAYARAN", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun StatusButton(label: String, status: Status, selected: Status, modifier: Modifier) { val color = when(status) { Status.LUNAS -> Green; Status.KURANG -> Orange; Status.BELUM -> Red }; Button(onClick = {}, enabled = false, modifier = modifier, contentPadding = PaddingValues(horizontal = 2.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selected == status) color else Color.White, disabledContainerColor = if (selected == status) color else Color(0xFFF2F4F3), disabledContentColor = if (selected == status) Color.White else color), shape = RoundedCornerShape(10.dp)) { Text(label, fontSize = 9.sp, textAlign = TextAlign.Center) } }

@Composable
fun IconCircle(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(34.dp).clip(CircleShape).background(LightGreen).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ReportScreen(month: String, residents: List<Resident>, context: Context) {
    val paid = residents.count { it.paid >= it.due }; val less = residents.count { it.paid in 1 until it.due }; val unpaid = residents.count { it.paid == 0 }; val income = residents.sumOf { it.paid }; val due = residents.sumOf { it.due }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BrandHeader(compact = true); ScreenTop("Laporan Bulanan")
        Card(Modifier.padding(16.dp).fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) { Column(Modifier.padding(18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { IconCircle("‹", {}); Text(month, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.ExtraBold, color = Ink); IconCircle("›", {}) }; Spacer(Modifier.height(14.dp)); Text("Ringkasan", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold); ReportLine("Total Warga", residents.size.toString()); ReportLine("Sudah Bayar", paid.toString(), Green); ReportLine("Kurang Bayar", less.toString(), Orange); ReportLine("Belum Bayar", unpaid.toString(), Red); HorizontalDivider(Modifier.padding(vertical = 9.dp)); ReportLine("Total Seharusnya", rupiah(due)); ReportLine("Total Diterima", rupiah(income), Green); ReportLine("Sisa Tagihan", rupiah(due-income), Red) } }
        Text("Daftar Warga", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        residents.forEach { ResidentRow(it, {}, true) }
        Row(Modifier.padding(16.dp)) { Button(onClick = { shareReport(context, month, residents) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Blue), shape = RoundedCornerShape(11.dp)) { Text("Bagikan Laporan") }; Spacer(Modifier.width(8.dp)); OutlinedButton(onClick = { shareReport(context, month, residents) }, Modifier.weight(1f), shape = RoundedCornerShape(11.dp)) { Text("Export PDF") } }
    }
}

@Composable fun ReportLine(label: String, value: String, color: Color = Color.DarkGray) { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(label, Modifier.weight(1f), color = Muted, fontSize = 13.sp); Text(value, fontWeight = FontWeight.Bold, color = color, fontSize = 13.sp) } }

fun shareReport(context: Context, month: String, residents: List<Resident>) { val paid = residents.count { it.paid >= it.due }; val unpaid = residents.count { it.paid == 0 }; val less = residents.count { it.paid in 1 until it.due }; val income = residents.sumOf { it.paid }; val text = "KUTIPAN SAMPAH RT 01\nLaporan $month\n\nTotal Warga: ${residents.size}\nSudah Bayar: $paid\nKurang Bayar: $less\nBelum Bayar: $unpaid\nTotal Diterima: ${rupiah(income)}\n\nBersama menjaga lingkungan tetap bersih."; context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Bagikan laporan")) }

@Composable
fun DetailResident(r: Resident, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(PaleGreen)) {
        BrandHeader(compact = true); ScreenTop("Detail Warga", onBack)
        Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
            Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(62.dp).clip(CircleShape).background(Color(0xFFE8F3FF)), contentAlignment = Alignment.Center) { Text("●", color = Blue, fontSize = 35.sp) }; Spacer(Modifier.width(12.dp)); Column { Text(r.name, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Text(r.house, color = Muted); Text(if (r.phone.isBlank()) "Nomor HP belum diisi" else r.phone, color = Muted, fontSize = 12.sp) } }; Spacer(Modifier.height(14.dp)); Row { Button({}, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Blue), shape = RoundedCornerShape(11.dp)) { Text("Edit") }; Spacer(Modifier.width(8.dp)); Button({}, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Red), shape = RoundedCornerShape(11.dp)) { Text("Hapus") }; }; Spacer(Modifier.height(20.dp)); Text("Riwayat Pembayaran", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold); listOf("September 2026" to r.paid, "Agustus 2026" to r.due, "Juli 2026" to r.due, "Juni 2026" to r.due, "Mei 2026" to r.due, "April 2026" to r.paid).forEach { (m, v) -> val s = if (v >= r.due) Status.LUNAS else if (v > 0) Status.KURANG else Status.BELUM; val c = when(s){Status.LUNAS->Green;Status.KURANG->Orange;Status.BELUM->Red}; Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(11.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(m, Modifier.weight(1f)); Text(if(s==Status.LUNAS) "Lunas" else if(s==Status.KURANG) "Kurang Bayar" else "Belum Bayar", color = c, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.width(8.dp)); Text(rupiah(v), fontWeight = FontWeight.Bold, fontSize = 11.sp) } } } }
        }
    }
}

@Composable
fun MoreScreen(onReminder: () -> Unit, onPassword: () -> Unit, logout: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BrandHeader(); ScreenTop("Lainnya")
        MoreItem("⚙", "Pengaturan Iuran", "Atur nominal iuran per bulan") {}
        MoreItem("⌂", "Pengaturan RT", "Nama RT, alamat, logo") {}
        MoreItem("●", "Akun Admin", "Ubah password", onPassword)
        MoreItem("◫", "Backup & Restore", "Simpan atau pulihkan data") {}
        MoreItem("●", "Tentang Aplikasi", "Versi 1.0.0") {}
        MoreItem("🔔", "Pengingat Pembayaran", "12 warga belum membayar", onReminder)
        Button(onClick = logout, Modifier.fillMaxWidth().padding(16.dp).height(48.dp), colors = ButtonDefaults.buttonColors(Red), shape = RoundedCornerShape(13.dp)) { Text("LOGOUT", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun MoreItem(icon: String, title: String, subtitle: String, onClick: () -> Unit = {}) { Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(40.dp).clip(CircleShape).background(LightGreen), contentAlignment = Alignment.Center) { Text(icon, fontSize = 18.sp, color = Green) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 11.sp, color = Muted) }; Text("›", fontSize = 24.sp, color = Muted) } } }

@Composable
fun ReminderScreen(residents: List<Resident>, onBack: () -> Unit, onOpenUnpaid: () -> Unit) {
    val unpaid = residents.count { it.paid == 0 }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) {
        BrandHeader(compact = true); ScreenTop("Pengingat", onBack)
        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(130.dp).clip(CircleShape).background(Color(0xFFFFF1D6)), contentAlignment = Alignment.Center) { Text("🔔", fontSize = 58.sp) }; Spacer(Modifier.height(18.dp)); Text("Masih ada $unpaid warga\nyang belum membayar\niuran September 2026.", textAlign = TextAlign.Center, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); Text("Mari kita ingatkan warga agar segera melakukan pembayaran.", textAlign = TextAlign.Center, color = Muted); Spacer(Modifier.height(18.dp)); Button(onClick = onOpenUnpaid, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Lihat Warga Belum Bayar") }; OutlinedButton(onClick = {}, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("◉  Bagikan Pengingat via WhatsApp") } } }
    }
}

@Composable
fun PasswordScreen(onBack: () -> Unit) {
    var old by remember { mutableStateOf("") }; var new by remember { mutableStateOf("") }; var confirm by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(PaleGreen)) { BrandHeader(compact = true); ScreenTop("Ubah Password", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { PasswordField("Password Lama", old) { old = it }; Spacer(Modifier.height(12.dp)); PasswordField("Password Baru", new) { new = it }; Spacer(Modifier.height(12.dp)); PasswordField("Konfirmasi Password Baru", confirm) { confirm = it }; Spacer(Modifier.height(18.dp)); Button(onClick = {}, Modifier.fillMaxWidth().height(48.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("SIMPAN", fontWeight = FontWeight.Bold) } } } }
}

@Composable fun PasswordField(label: String, value: String, onValue: (String) -> Unit) { OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(11.dp)) }

@Composable
fun BottomNav(current: Tab, onSelect: (Tab) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        val items = listOf(Tab.DASHBOARD to ("⌂" to "Dashboard"), Tab.WARGA to ("♙" to "Warga"), Tab.BAYAR to ("▣" to "Bayar"), Tab.LAPORAN to ("▤" to "Laporan"), Tab.LAINNYA to ("⋯" to "Lainnya"))
        items.forEach { (tab, pair) -> NavigationBarItem(selected = current == tab, onClick = { onSelect(tab) }, icon = { Text(pair.first, fontSize = 21.sp, color = if(current == tab) Green else Muted) }, label = { Text(pair.second, fontSize = 9.sp) }) }
    }
}

fun sampleResidents() = emptyList<Resident>()

/*
fun sampleResidentsLegacy() = listOf(
    Resident("Ahmad Fauzi", "Rumah 01", "0812 3456 7890", 10000, 10000),
    Resident("Budi Santoso", "Rumah 02", "0811 222 222", 0, 10000),
    Resident("Candra Wijaya", "Rumah 03", "0812 3333 4444", 10000, 10000),
    Resident("Dedi Kurniawan", "Rumah 04", "", 5000, 10000),
    Resident("Eko Prasetyo", "Rumah 05", "0813 5555 6666", 10000, 10000),
    Resident("Fajar Hidayat", "Rumah 06", "0812 7777 8888", 0, 10000),
    Resident("Gita Lestari", "Rumah 07", "0813 9999 0000", 10000, 10000),
    Resident("Hendra Saputra", "Rumah 08", "", 0, 10000)
)
*/
