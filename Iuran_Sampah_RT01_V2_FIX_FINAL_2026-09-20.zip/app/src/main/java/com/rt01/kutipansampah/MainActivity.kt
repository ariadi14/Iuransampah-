package com.rt01.kutipansampah

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val Green = Color(0xFF087F5B)
private val DarkGreen = Color(0xFF14532D)
private val LightGreen = Color(0xFFEAF8F2)
private val PaleGreen = Color(0xFFF4FBF7)
private val Orange = Color(0xFFF59F00)
private val Red = Color(0xFFE03131)
private val Blue = Color(0xFF1971C2)
private val Purple = Color(0xFF6F42C1)
private val Ink = Color(0xFF18201C)
private val Muted = Color(0xFF718078)

private fun rupiah(v: Int): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }.format(v)
private fun monthKey(c: Calendar): String = SimpleDateFormat("yyyy-MM", Locale.US).format(c.time)
private fun monthLabel(c: Calendar): String = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(c.time).replaceFirstChar { it.uppercase() }
private fun timeLabel(): String = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())
private fun todayLabel(): String = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(Date()).replaceFirstChar { it.uppercase() }

private data class Resident(
    val id: Long,
    val name: String,
    val house: String,
    val phone: String,
    val note: String,
    val payments: Map<String, Int> = emptyMap()
)

private enum class Tab { DASHBOARD, WARGA, BAYAR, LAPORAN, LAINNYA }
private enum class Status { LUNAS, KURANG, BELUM }
private enum class Screen { HOME, DETAIL, ADD, EDIT, PAYMENT, PASSWORD, IURAN, BACKUP, REMINDER, ABOUT }

private class AppStore(context: Context) {
    private val p = context.getSharedPreferences("rt01_store", Context.MODE_PRIVATE)
    var username: String
        get() = p.getString("username", "admin") ?: "admin"
        set(v) = p.edit().putString("username", v).apply()
    var password: String
        get() = p.getString("password", "admin123") ?: "admin123"
        set(v) = p.edit().putString("password", v).apply()
    var rememberedUser: String
        get() = p.getString("remember_user", "") ?: ""
        set(v) = p.edit().putString("remember_user", v).apply()
    var rememberedPass: String
        get() = p.getString("remember_pass", "") ?: ""
        set(v) = p.edit().putString("remember_pass", v).apply()
    var rememberMe: Boolean
        get() = p.getBoolean("remember_me", false)
        set(v) = p.edit().putBoolean("remember_me", v).apply()
    var fee: Int
        get() = p.getInt("fee", 10000)
        set(v) = p.edit().putInt("fee", v).apply()
    var residents: List<Resident>
        get() = decodeResidents(p.getString("residents", "[]") ?: "[]")
        set(v) = p.edit().putString("residents", encodeResidents(v)).apply()

    private fun encodeResidents(list: List<Resident>): String = JSONArray().apply {
        list.forEach { r ->
            put(JSONObject().apply {
                put("id", r.id); put("name", r.name); put("house", r.house); put("phone", r.phone); put("note", r.note)
                put("payments", JSONObject().apply { r.payments.forEach { (k, v) -> put(k, v) } })
            })
        }
    }.toString()

    private fun decodeResidents(raw: String): List<Resident> = runCatching {
        val a = JSONArray(raw); buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val po = o.optJSONObject("payments") ?: JSONObject(); val map = mutableMapOf<String, Int>()
                po.keys().forEach { k -> map[k] = po.optInt(k, 0) }
                add(Resident(o.optLong("id", System.currentTimeMillis() + i), o.optString("name"), o.optString("house"), o.optString("phone"), o.optString("note"), map))
            }
        }
    }.getOrDefault(emptyList())

    fun exportJson(): String = JSONObject().apply {
        put("fee", fee)
        put("username", username)
        put("password", password)
        put("residents", JSONArray(encodeResidents(residents)))
    }.toString(2)
    fun importJson(raw: String): Boolean = runCatching {
        val o = JSONObject(raw)
        fee = o.optInt("fee", fee)
        username = o.optString("username", username)
        password = o.optString("password", password)
        if (rememberMe) rememberedPass = password
        residents = decodeResidents(o.optJSONArray("residents")?.toString() ?: "[]")
        true
    }.getOrDefault(false)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KutipanApp(this) }
    }
}

@Composable
private fun KutipanApp(context: Context) {
    val store = remember { AppStore(context) }
    var loggedIn by remember { mutableStateOf(store.rememberMe && store.rememberedUser.isNotBlank() && store.rememberedPass.isNotBlank()) }
    if (!loggedIn) LoginScreen(store) { loggedIn = true } else MainShell(context, store) { loggedIn = false }
}

@Composable
private fun LoginScreen(store: AppStore, onLogin: () -> Unit) {
    var user by remember { mutableStateOf(if (store.rememberMe) store.rememberedUser else "") }
    var pass by remember { mutableStateOf(if (store.rememberMe) store.rememberedPass else "") }
    var rememberMe by remember { mutableStateOf(store.rememberMe) }
    var error by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(PaleGreen)) {
        Image(
            painterResource(R.drawable.login_bg),
            null,
            Modifier.fillMaxWidth().aspectRatio(691f / 560f),
            contentScale = ContentScale.FillWidth,
            alignment = Alignment.TopCenter
        )
        Column(Modifier.fillMaxWidth().padding(horizontal = 68.dp).padding(top = 300.dp).verticalScroll(rememberScrollState())) {
            Surface(color = Color.White.copy(alpha = .86f), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    OutlinedTextField(user, { user = it; error = false }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(pass, { pass = it; error = false }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(rememberMe, { rememberMe = it }); Text("Ingat saya", color = DarkGreen) }
                    if (error) Text("Username atau password salah.", color = Red, fontSize = 12.sp)
                    Button(onClick = {
                        if (user == store.username && pass == store.password) {
                            store.rememberMe = rememberMe
                            if (rememberMe) { store.rememberedUser = user; store.rememberedPass = pass } else { store.rememberedUser = ""; store.rememberedPass = "" }
                            onLogin()
                        } else error = true
                    }, Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(18.dp)) { Text("LOGIN", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) }
                }
            }
        }
    }
}

@Composable
private fun MainShell(context: Context, store: AppStore, logout: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var paymentMonth by remember { mutableStateOf(Calendar.getInstance()) }
    var reportMonth by remember { mutableStateOf(Calendar.getInstance()) }
    var filter by remember { mutableStateOf<Status?>(null) }
    var residents by remember { mutableStateOf(store.residents) }
    var fee by remember { mutableStateOf(store.fee) }

    fun saveResidents(v: List<Resident>) { residents = v; store.residents = v }
    fun go(t: Tab) { tab = t; screen = Screen.HOME; selectedId = null }
    fun selected(): Resident? = residents.firstOrNull { it.id == selectedId }

    when (screen) {
        Screen.DETAIL -> selected()?.let { DetailResident(it, fee, { screen = Screen.HOME }, { screen = Screen.EDIT }, { saveResidents(residents.filterNot { r -> r.id == it.id }); screen = Screen.HOME }) } ?: run { screen = Screen.HOME }
        Screen.ADD -> ResidentForm(null, { screen = Screen.HOME }, { name, house, phone, note -> saveResidents(residents + Resident(System.currentTimeMillis(), name, house, phone, note)); screen = Screen.HOME })
        Screen.EDIT -> selected()?.let { r -> ResidentForm(r, { screen = Screen.DETAIL }, { name, house, phone, note -> saveResidents(residents.map { x -> if (x.id == r.id) x.copy(name = name, house = house, phone = phone, note = note) else x }); screen = Screen.DETAIL }) } ?: run { screen = Screen.HOME }
        Screen.PAYMENT -> selected()?.let { r -> PaymentForm(
            r, paymentMonth, fee,
            { screen = Screen.HOME },
            { monthKeyValue, amount ->
                val map = r.payments.toMutableMap()
                map[monthKeyValue] = amount
                saveResidents(residents.map { x -> if (x.id == r.id) x.copy(payments = map) else x })
                screen = Screen.HOME
            }
        ) } ?: run { screen = Screen.HOME }
        Screen.PASSWORD -> PasswordSettings(store) { screen = Screen.HOME }
        Screen.IURAN -> FeeSettings(fee) { fee = it; store.fee = it; screen = Screen.HOME }
        Screen.BACKUP -> BackupRestore(context, store, { residents = store.residents; fee = store.fee; screen = Screen.HOME }, { screen = Screen.HOME })
        Screen.REMINDER -> ReminderScreen(residents, fee, { screen = Screen.HOME }, { tab = Tab.BAYAR; filter = Status.BELUM; screen = Screen.HOME })
        Screen.ABOUT -> AboutScreen { screen = Screen.HOME }
        Screen.HOME -> Scaffold(bottomBar = { BottomNav(tab) { go(it) } }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad).background(PaleGreen)) {
                when (tab) {
                    Tab.DASHBOARD -> Dashboard(residents, fee, { go(Tab.WARGA) }, { filter = it; go(Tab.BAYAR) }, { go(Tab.LAPORAN) }, { selectedId = it.id; screen = Screen.DETAIL })
                    Tab.WARGA -> ResidentsScreen(residents, { selectedId = it.id; screen = Screen.DETAIL }, { screen = Screen.ADD })
                    Tab.BAYAR -> PaymentOverview(residents, fee, paymentMonth, filter, { filter = it }, { selectedId = it.id; screen = Screen.PAYMENT })
                    Tab.LAPORAN -> ReportScreen(residents, fee, reportMonth, context, { reportMonth = it })
                    Tab.LAINNYA -> MoreScreen(residents, fee, { screen = Screen.IURAN }, { screen = Screen.PASSWORD }, { screen = Screen.BACKUP }, { screen = Screen.REMINDER }, { screen = Screen.ABOUT }, logout)
                }
            }
        }
    }
}

@Composable
private fun Hero(resId: Int) { Image(painterResource(resId), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop) }

@Composable
private fun DetailHero(resId: Int, title: String, subtitle: String) {
    Box(Modifier.fillMaxWidth().height(250.dp)) {
        Image(painterResource(resId), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.16f)))
        Column(Modifier.align(Alignment.Center).padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(color = Color.White.copy(alpha = 0.94f), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(title, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen, textAlign = TextAlign.Center)
                    Text(subtitle, fontSize = 13.sp, color = Green, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun Dashboard(residents: List<Resident>, fee: Int, onWarga: () -> Unit, onBayar: (Status) -> Unit, onReport: () -> Unit, onDetail: (Resident) -> Unit) {
    var selectedDay by remember { mutableStateOf(Calendar.getInstance()) }
    val key = monthKey(selectedDay)
    val paid = residents.count { (it.payments[key] ?: 0) >= fee }
    val unpaid = residents.count { (it.payments[key] ?: 0) == 0 }
    val income = residents.sumOf { it.payments[key] ?: 0 }
    var time by remember { mutableStateOf(timeLabel()) }
    var date by remember { mutableStateOf(SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(selectedDay.time).replaceFirstChar { it.uppercase() }) }
    LaunchedEffect(selectedDay.timeInMillis) { date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(selectedDay.time).replaceFirstChar { it.uppercase() } }
    LaunchedEffect(Unit) { while (true) { time = timeLabel(); kotlinx.coroutines.delay(1000) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Image(painterResource(R.drawable.dashboard_bg), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop)
        Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(Color.White)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconCircle("‹", { val c = selectedDay.clone() as Calendar; c.add(Calendar.DAY_OF_MONTH, -1); selectedDay = c }, LightGreen, Green); Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { Text(time, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen); Text(date, color = Muted, fontWeight = FontWeight.SemiBold) }; IconCircle("›", { val c = selectedDay.clone() as Calendar; c.add(Calendar.DAY_OF_MONTH, 1); selectedDay = c }, LightGreen, Green)
            }
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clickable { onReport() }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(Color(0xFF16A36F))) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Text("▤", fontSize = 42.sp, color = Color.White); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Laporan", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Text("Total Pemasukan dari Warga", color = Color.White, fontSize = 16.sp); Text(rupiah(income), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }; Text("›", fontSize = 38.sp, color = Color.White) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("👥", "Total Warga", residents.size.toString(), Blue, Modifier.weight(1f)) { onWarga() }
            StatCard("✓", "Sudah Bayar", paid.toString(), Green, Modifier.weight(1f)) { onBayar(Status.LUNAS) }
            StatCard("×", "Belum Bayar", unpaid.toString(), Red, Modifier.weight(1f)) { onBayar(Status.BELUM) }
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(Color(0xFFFFE9E9))) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("🔔", fontSize = 38.sp); Text("Pemberitahuan", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink); Text("Warga yang belum melakukan pembayaran bulan ini", color = Muted, textAlign = TextAlign.Center); Text("$unpaid Warga Belum Bayar", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Red, modifier = Modifier.padding(top = 8.dp)); Text("Segera lakukan pembayaran untuk menjaga kebersihan lingkungan kita bersama.", color = Red, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)) }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun StatCard(icon: String, label: String, value: String, color: Color, modifier: Modifier, onClick: () -> Unit) { Card(modifier.clickable { onClick() }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) { Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(44.dp).clip(CircleShape).background(color.copy(.12f)), contentAlignment = Alignment.Center) { Text(icon, fontSize = 22.sp, color = color, fontWeight = FontWeight.Bold) }; Text(label, fontSize = 11.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold); Text(value, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = color); Text("Warga", fontSize = 10.sp, color = Muted) } } }

@Composable
private fun ResidentsScreen(residents: List<Resident>, onResident: (Resident) -> Unit, onAdd: () -> Unit) {
    var query by remember { mutableStateOf("") }; val filtered = residents.filter { it.name.contains(query, true) || it.house.contains(query, true) }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().background(PaleGreen)) {
        Image(painterResource(R.drawable.warga_bg), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, placeholder = { Text("Cari nama atau nomor rumah...", fontSize = 13.sp) }, leadingIcon = { Text("⌕", fontSize = 24.sp) }, modifier = Modifier.weight(1f).height(52.dp), singleLine = true, shape = RoundedCornerShape(18.dp), textStyle = LocalTextStyle.current.copy(fontSize = 14.sp))
            Spacer(Modifier.width(8.dp)); Button(onClick = onAdd, modifier = Modifier.width(116.dp).height(52.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Text("+ Tambah Warga", fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, softWrap = false) }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
            if (filtered.isEmpty()) item { EmptyState("Belum ada data warga", "Tambahkan warga melalui tombol Tambah") }
            else itemsIndexed(filtered) { i, r ->
                val sameInitialBefore = filtered.take(i).count { it.name.trim().firstOrNull()?.uppercase() == r.name.trim().firstOrNull()?.uppercase() }
                ResidentRow(r, onResident, false, i + 1, sameInitialBefore)
            }
        }
    }
}

private fun residentColor(r: Resident, variant: Int): Color {
    val palettes = listOf(
        listOf(Color(0xFF14B8A6), Color(0xFF0F9F8A), Color(0xFF2DD4BF), Color(0xFF0D9488), Color(0xFF5EEAD4)),
        listOf(Color(0xFF5B5FEF), Color(0xFF4338CA), Color(0xFF6366F1), Color(0xFF7C3AED), Color(0xFF818CF8)),
        listOf(Color(0xFFFF6B35), Color(0xFFF97316), Color(0xFFEA580C), Color(0xFFFF8A4C), Color(0xFFF59E0B)),
        listOf(Color(0xFFE83E8C), Color(0xFFDB2777), Color(0xFFEC4899), Color(0xFFC026D3), Color(0xFFF472B6)),
        listOf(Color(0xFF179BD7), Color(0xFF0284C7), Color(0xFF0EA5E9), Color(0xFF2563EB), Color(0xFF38BDF8)),
        listOf(Color(0xFFFFB000), Color(0xFFEAB308), Color(0xFFF59E0B), Color(0xFFD97706), Color(0xFFFACC15)),
        listOf(Color(0xFF8E44AD), Color(0xFF7C3AED), Color(0xFF9333EA), Color(0xFFA855F7), Color(0xFFC084FC)),
        listOf(Color(0xFF16A34A), Color(0xFF15803D), Color(0xFF22C55E), Color(0xFF059669), Color(0xFF4ADE80)),
        listOf(Color(0xFFEF4444), Color(0xFFDC2626), Color(0xFFF43F5E), Color(0xFFB91C1C), Color(0xFFFB7185))
    )
    val initialIndex = ((r.name.trim().firstOrNull()?.uppercaseChar()?.code ?: 0) - 'A'.code).let { if (it < 0) 0 else it } % palettes.size
    return palettes[initialIndex][variant % 5]
}

@Composable private fun ResidentRow(r: Resident, onClick: (Resident) -> Unit, showStatus: Boolean, index: Int?, variant: Int) {
    val c = residentColor(r, variant); val initial = r.name.trim().firstOrNull()?.uppercase() ?: "?"
    Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp).clickable { onClick(r) }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (index != null) { Box(Modifier.size(34.dp).clip(CircleShape).background(LightGreen), contentAlignment = Alignment.Center) { Text(index.toString(), color = Green, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(8.dp)) }
        Box(Modifier.size(52.dp).clip(CircleShape).background(c), contentAlignment = Alignment.Center) { Text(initial, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold) }
        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.ExtraBold, color = Ink, fontSize = 17.sp); Text(r.house, fontSize = 13.sp, color = Muted) }
        Text("›", fontSize = 32.sp, color = Muted)
    } }
}

@Composable
private fun ResidentForm(existing: Resident?, onBack: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }; var house by remember { mutableStateOf(existing?.house ?: "") }; var phone by remember { mutableStateOf(existing?.phone ?: "") }; var note by remember { mutableStateOf(existing?.note ?: "") }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { DetailHero(R.drawable.warga_header_final, if (existing == null) "Tambah Warga" else "Edit Warga", "Lengkapi data warga dengan rapi"); BackOnly(onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text(if (existing == null) "Tambah Data Warga Baru" else "Edit Data Warga", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(14.dp)); OutlinedTextField(name, { name = it }, label = { Text("Nama Warga *") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(10.dp)); OutlinedTextField(house, { house = it }, label = { Text("Nomor Rumah *") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(10.dp)); OutlinedTextField(phone, { phone = it }, label = { Text("Nomor HP") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(10.dp)); OutlinedTextField(note, { note = it }, label = { Text("Keterangan") }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(16.dp)); Row { OutlinedButton(onClick = onBack, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Batal") }; Spacer(Modifier.width(8.dp)); Button(onClick = { if (name.isNotBlank() && house.isNotBlank()) onSave(name.trim(), house.trim(), phone.trim(), note.trim()) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Simpan", fontWeight = FontWeight.Bold) } } } } }
}

@Composable
private fun DetailResident(r: Resident, fee: Int, onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { DetailHero(R.drawable.warga_header_final, "Detail Warga", "Data warga dan riwayat pembayaran"); BackOnly(onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(62.dp).clip(CircleShape).background(Color(0xFFE8F3FF)), contentAlignment = Alignment.Center) { Text("●", color = Blue, fontSize = 35.sp) }; Spacer(Modifier.width(12.dp)); Column { Text(r.name, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Text(r.house, color = Muted); Text(if (r.phone.isBlank()) "Nomor HP belum diisi" else r.phone, color = Muted, fontSize = 12.sp) } }; Spacer(Modifier.height(14.dp)); Row { Button(onClick = onEdit, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(11.dp)) { Text("Edit") }; Spacer(Modifier.width(8.dp)); Button(onClick = { confirm = true }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Red), shape = RoundedCornerShape(11.dp)) { Text("Hapus") } }; Spacer(Modifier.height(20.dp)); Text("Riwayat Pembayaran", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold); val c = Calendar.getInstance(); repeat(6) { idx -> val m = (c.clone() as Calendar).apply { add(Calendar.MONTH, -idx) }; val amount = r.payments[monthKey(m)] ?: 0; val status = when { amount >= fee -> Status.LUNAS; amount > 0 -> Status.KURANG; else -> Status.BELUM }; val color = when (status) { Status.LUNAS -> Green; Status.KURANG -> Orange; Status.BELUM -> Red }; Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(11.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(monthLabel(m), Modifier.weight(1f)); Text(when (status) { Status.LUNAS -> "Sudah Bayar"; Status.KURANG -> "Kurang Bayar"; Status.BELUM -> "Belum Bayar" }, color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.width(8.dp)); Text(rupiah(amount), fontWeight = FontWeight.Bold, fontSize = 11.sp) } } } } } }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Hapus warga?") }, text = { Text("Data ${r.name} akan dihapus dari daftar warga.") }, confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Hapus", color = Red) } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } })
}

@Composable
private fun PaymentOverview(residents: List<Resident>, fee: Int, month: Calendar, filter: Status?, onFilter: (Status?) -> Unit, onPay: (Resident) -> Unit) {
    val key = monthKey(month); var query by remember { mutableStateOf("") }; var showPicker by remember { mutableStateOf(false) }
    val filtered = residents.filter { r -> val a = r.payments[key] ?: 0; val match = r.name.contains(query, true) || r.house.contains(query, true); match && when (filter) { Status.LUNAS -> a >= fee; Status.BELUM -> a == 0; Status.KURANG -> a in 1 until fee; null -> true } }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().background(PaleGreen)) {
        Image(painterResource(R.drawable.payment_bg), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterButton("Semua", filter == null, null, onFilter); FilterButton("Sudah Bayar", filter == Status.LUNAS, Status.LUNAS, onFilter); FilterButton("Belum Bayar", filter == Status.BELUM, Status.BELUM, onFilter) }
        OutlinedTextField(query, { query = it }, placeholder = { Text("Cari nama atau nomor rumah...", fontSize = 13.sp) }, leadingIcon = { Text("⌕", fontSize = 24.sp) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp).height(52.dp), singleLine = true, shape = RoundedCornerShape(18.dp), textStyle = LocalTextStyle.current.copy(fontSize = 14.sp))
        Button(onClick = { showPicker = true }, enabled = residents.isNotEmpty(), modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp).height(54.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(17.dp)) { Text("CATAT PEMBAYARAN", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
            if (filtered.isEmpty()) item { EmptyState("Tidak ada warga", "Ubah pencarian atau filter pembayaran") } else itemsIndexed(filtered) { i, r ->
                val sameInitialBefore = filtered.take(i).count { it.name.trim().firstOrNull()?.uppercase() == r.name.trim().firstOrNull()?.uppercase() }
                ResidentPaymentRow(r, fee, key, sameInitialBefore, onPay)
            }
        }
    }
    if (showPicker) AlertDialog(onDismissRequest = { showPicker = false }, title = { Text("Pilih Warga", fontWeight = FontWeight.ExtraBold) }, text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) { residents.sortedBy { it.name }.forEach { r -> TextButton(onClick = { showPicker = false; onPay(r) }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) { Text(r.name, fontWeight = FontWeight.Bold); Text(r.house, color = Muted, fontSize = 12.sp) } } } } }, confirmButton = { TextButton(onClick = { showPicker = false }) { Text("Batal") } })
}

@Composable private fun FilterButton(label: String, selected: Boolean, status: Status?, onClick: (Status?) -> Unit) { Button(onClick = { onClick(status) }, colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFFE7D8F7) else Color.White, contentColor = Ink), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) } }

@Composable private fun ResidentPaymentRow(r: Resident, fee: Int, key: String, variant: Int, onClick: (Resident) -> Unit) { val amount = r.payments[key] ?: 0; val status = when { amount >= fee -> Status.LUNAS; amount > 0 -> Status.KURANG; else -> Status.BELUM }; val statusColor = when (status) { Status.LUNAS -> Green; Status.KURANG -> Orange; Status.BELUM -> Red }; val avatar = residentColor(r, variant); val initial = r.name.trim().firstOrNull()?.uppercase() ?: "?"; Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clickable { onClick(r) }, colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(46.dp).clip(CircleShape).background(avatar), contentAlignment = Alignment.Center) { Text(initial, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }; Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.Bold); Text(r.house, color = Muted, fontSize = 12.sp); Text(when (status) { Status.LUNAS -> "Sudah Bayar"; Status.KURANG -> "Kurang Bayar"; Status.BELUM -> "Belum Bayar" }, color = statusColor, fontWeight = FontWeight.Bold, fontSize = 11.sp) }; Text("›", fontSize = 28.sp, color = Muted) } } }

@Composable
private fun PaymentForm(
    r: Resident, monthStart: Calendar, fee: Int,
    onBack: () -> Unit, onSave: (String, Int) -> Unit
) {
    var month by remember { mutableStateOf(monthStart.clone() as Calendar) }
    var status by remember {
        mutableStateOf(
            if ((r.payments[monthKey(month)] ?: 0) >= fee) Status.LUNAS else Status.BELUM
        )
    }

    fun refreshFor(c: Calendar) {
        month = c
        status = if ((r.payments[monthKey(c)] ?: 0) >= fee) Status.LUNAS else Status.BELUM
    }

    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) {
        DetailHero(R.drawable.payment_header_final, "Pembayaran", "Catat iuran warga per bulan")
        BackOnly(onBack)
        Card(
            Modifier.fillMaxWidth().padding(16.dp),
            colors = CardDefaults.cardColors(Color.White),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Warga", color = Muted, fontSize = 12.sp)
                Text(r.name, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(r.house, color = Muted)

                Spacer(Modifier.height(18.dp))
                Text("Bulan Pembayaran", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconCircle("‹", {
                        val c = month.clone() as Calendar
                        c.add(Calendar.MONTH, -1)
                        refreshFor(c)
                    })
                    Text(
                        monthLabel(month),
                        Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp
                    )
                    IconCircle("›", {
                        val c = month.clone() as Calendar
                        c.add(Calendar.MONTH, 1)
                        refreshFor(c)
                    })
                }

                Spacer(Modifier.height(16.dp))
                Text("Nominal Iuran", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    rupiah(fee), {}, Modifier.fillMaxWidth(),
                    enabled = false,
                    shape = RoundedCornerShape(13.dp)
                )

                Spacer(Modifier.height(16.dp))
                Text("Status Pembayaran", fontWeight = FontWeight.Bold)
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatusChoice(
                        "Sudah Bayar", Status.LUNAS, status, Modifier.weight(1f)
                    ) { status = it }
                    StatusChoice(
                        "Belum Bayar", Status.BELUM, status, Modifier.weight(1f)
                    ) { status = it }
                }

                Surface(
                    color = if (status == Status.LUNAS) Green.copy(.10f) else Red.copy(.08f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        if (status == Status.LUNAS)
                            "Pembayaran bulan ini akan dicatat sebesar ${rupiah(fee)}."
                        else
                            "Belum ada pembayaran untuk bulan ini.",
                        Modifier.padding(14.dp),
                        color = if (status == Status.LUNAS) Green else Red,
                        fontSize = 12.sp
                    )
                }

                Spacer(Modifier.height(20.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onBack,
                        Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Batal")
                    }
                    Spacer(Modifier.width(7.dp))
                    Button(
                        onClick = {
                            onSave(
                                monthKey(month),
                                if (status == Status.LUNAS) fee else 0
                            )
                        },
                        Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(Green),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Simpan", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable private fun StatusChoice(label: String, value: Status, selected: Status, modifier: Modifier, onClick: (Status) -> Unit) { val c = if (value == Status.LUNAS) Green else if (value == Status.KURANG) Orange else Red; OutlinedButton(onClick = { onClick(value) }, modifier = modifier, colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selected == value) c.copy(.12f) else Color.Transparent, contentColor = c), border = ButtonDefaults.outlinedButtonBorder, shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(4.dp)) { Text(label, fontSize = 9.sp, textAlign = TextAlign.Center) } }

@Composable
private fun ReportScreen(residents: List<Resident>, fee: Int, monthStart: Calendar, context: Context, onMonth: (Calendar) -> Unit) {
    var month by remember { mutableStateOf(monthStart.clone() as Calendar) }; val key = monthKey(month)
    val due = residents.size * fee; val income = residents.sumOf { it.payments[key] ?: 0 }; val outstanding = (due - income).coerceAtLeast(0); val progress = if (due == 0) 0 else (income * 100 / due).coerceIn(0, 100)
    val paid = residents.count { (it.payments[key] ?: 0) >= fee }; val unpaid = residents.count { (it.payments[key] ?: 0) < fee }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) {
        Image(painterResource(R.drawable.report_bg), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { IconCircle("‹", { val c = month.clone() as Calendar; c.add(Calendar.MONTH, -1); month = c; onMonth(c) }, LightGreen, Green); Text(monthLabel(month), Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Ink); IconCircle("›", { val c = month.clone() as Calendar; c.add(Calendar.MONTH, 1); month = c; onMonth(c) }, LightGreen, Green) }
        Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("▥", fontSize = 30.sp, color = Green); Spacer(Modifier.width(10.dp)); Text("Ringkasan Keuangan", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen) }
            HorizontalDivider(Modifier.padding(vertical = 8.dp)); ReportLine("Total Seharusnya", rupiah(due), Ink); ReportLine("Total Diterima", rupiah(income), Green); ReportLine("Sisa Tagihan", rupiah(outstanding), Red)
        } }
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(108.dp).clip(CircleShape).background(Color(0xFFDCEDE7)), contentAlignment = Alignment.Center) { Text("$progress%", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Ink) }; Text("Realisasi Pembayaran", fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center); Text("Berdasarkan pembayaran bulan ${monthLabel(month)}", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) } }
            Card(Modifier.weight(1f), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("👥", fontSize = 42.sp); Text("Total Warga", fontWeight = FontWeight.ExtraBold); Text(residents.size.toString(), fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen); Text("Warga", color = Muted) } }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SmallReportStatus("✓", "Sudah Bayar", paid, Green, Modifier.weight(1f)); SmallReportStatus("×", "Belum Bayar", unpaid, Red, Modifier.weight(1f))
        }
        Button(onClick = { shareReportImage(context, monthLabel(month), key, residents, fee) }, Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp).height(55.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(16.dp)) { Text("⌯   Bagikan Laporan   ›", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
        OutlinedButton(onClick = { exportReportPdf(context, monthLabel(month), key, residents, fee) }, Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("▤   Lihat Detail Laporan   ›", fontWeight = FontWeight.Bold, color = DarkGreen) }
        Card(Modifier.fillMaxWidth().padding(18.dp), colors = CardDefaults.cardColors(Color(0xFFDFF4E9)), shape = RoundedCornerShape(18.dp)) { Text("“Pembayaran iuran mendukung lingkungan yang lebih bersih dan sehat.”", Modifier.padding(16.dp), color = DarkGreen, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun SmallReportStatus(icon: String, label: String, value: Int, color: Color, modifier: Modifier) { Card(modifier, colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(40.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) { Text(icon, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(8.dp)); Column { Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text(value.toString(), fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = color); Text("Warga", color = Muted, fontSize = 10.sp) } } } }

@Composable private fun ReportLine(label: String, value: String, color: Color = Ink) { Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) { Text(label, Modifier.weight(1f), color = Muted, fontSize = 14.sp); Text(value, fontWeight = FontWeight.ExtraBold, color = color, fontSize = 15.sp) } }

private fun drawReportCanvas(context: Context, c: Canvas, w: Int, h: Int, month: String, monthKeyValue: String, residents: List<Resident>, fee: Int) {
    val template = BitmapFactory.decodeResource(context.resources, R.drawable.laporan_keuangan_final)
    val scale = w / template.width.toFloat()
    val dst = android.graphics.Rect(0, 0, w, (template.height * scale).toInt())
    c.drawBitmap(template, null, dst, Paint(Paint.ANTI_ALIAS_FLAG))

    val income = residents.sumOf { it.payments[monthKeyValue] ?: 0 }
    val due = residents.size * fee
    val outstanding = (due - income).coerceAtLeast(0)
    val paid = residents.count { (it.payments[monthKeyValue] ?: 0) >= fee }
    val unpaid = (residents.size - paid).coerceAtLeast(0)
    val realization = if (due == 0) 0 else ((income.toDouble() / due.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)
    val paidPercent = if (residents.isEmpty()) 0 else ((paid.toDouble() / residents.size.toDouble()) * 100.0).roundToInt()
    val unpaidPercent = if (residents.isEmpty()) 0 else 100 - paidPercent
    val paidAmount = residents.sumOf { minOf(it.payments[monthKeyValue] ?: 0, fee) }
    val unpaidAmount = residents.sumOf { (fee - (it.payments[monthKeyValue] ?: 0)).coerceAtLeast(0) }

    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun rect(l: Float, t: Float, r: Float, b: Float, color: Int, rad: Float = 0f) {
        p.color = color
        if (rad > 0f) c.drawRoundRect(l * scale, t * scale, r * scale, b * scale, rad * scale, rad * scale, p)
        else c.drawRect(l * scale, t * scale, r * scale, b * scale, p)
    }
    fun txt(s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) {
        p.color = color; p.textSize = size * scale; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; p.textAlign = align
        c.drawText(s, x * scale, y * scale, p)
    }
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int = android.graphics.Color.rgb(205, 220, 213)) {
        p.color = color; p.strokeWidth = 1f * scale; c.drawLine(x1 * scale, y1 * scale, x2 * scale, y2 * scale, p)
    }

    // Period pill: restore the fixed label and inject the actual selected month.
    rect(337f, 207f, 688f, 251f, android.graphics.Color.rgb(8,127,91), 22f)
    txt("▣", 363f, 238f, 20f, android.graphics.Color.WHITE, true)
    txt("Periode: $month", 410f, 236f, 20f, android.graphics.Color.WHITE, false)

    // Summary cards: clear example values and write live values.
    rect(105f, 478f, 276f, 548f, android.graphics.Color.rgb(236,248,242), 6f)
    rect(380f, 478f, 514f, 548f, android.graphics.Color.rgb(232,244,252), 6f)
    rect(600f, 478f, 760f, 548f, android.graphics.Color.rgb(255,238,239), 6f)
    rect(868f, 478f, 972f, 548f, android.graphics.Color.rgb(244,238,255), 6f)
    txt(rupiah(due), 120f, 526f, 27f, android.graphics.Color.rgb(8,90,62), true)
    txt(rupiah(income), 382f, 526f, 27f, android.graphics.Color.rgb(25,105,210), true)
    txt(rupiah(outstanding), 605f, 526f, 27f, android.graphics.Color.rgb(224,49,49), true)
    txt(residents.size.toString(), 915f, 516f, 32f, android.graphics.Color.rgb(18,40,70), true, Paint.Align.CENTER)
    txt("Warga", 915f, 542f, 17f, android.graphics.Color.rgb(18,40,70), false, Paint.Align.CENTER)

    // Realisasi pembayaran: dynamic donut + status percentages.
    p.style = Paint.Style.STROKE; p.strokeWidth = 20f * scale; p.strokeCap = Paint.Cap.BUTT; p.color = android.graphics.Color.rgb(214,236,228)
    c.drawArc(72f*scale, 594f*scale, 212f*scale, 734f*scale, -90f, 360f, false, p)
    p.color = android.graphics.Color.rgb(8,127,91)
    c.drawArc(72f*scale, 594f*scale, 212f*scale, 734f*scale, -90f, 360f * realization / 100f, false, p)
    p.style = Paint.Style.FILL
    txt("$realization%", 142f, 690f, 35f, android.graphics.Color.rgb(18,40,70), true, Paint.Align.CENTER)
    // clear variable right-side realization values
    rect(290f, 635f, 610f, 680f, android.graphics.Color.WHITE)
    rect(290f, 687f, 610f, 725f, android.graphics.Color.WHITE)
    line(290f, 630f, 610f, 630f)
    line(290f, 683f, 610f, 683f)
    line(290f, 730f, 610f, 730f)
    p.color = android.graphics.Color.rgb(8,127,91); c.drawCircle(274f*scale, 656f*scale, 14f*scale, p)
    p.color = android.graphics.Color.rgb(224,49,49); c.drawCircle(274f*scale, 709f*scale, 14f*scale, p)
    txt("Sudah Bayar", 300f, 663f, 19f, android.graphics.Color.rgb(8,127,91), true)
    txt("$paid Warga", 455f, 663f, 18f, android.graphics.Color.DKGRAY, false)
    txt("$paidPercent%", 575f, 663f, 19f, android.graphics.Color.rgb(18,40,70), true, Paint.Align.RIGHT)
    txt("Belum Bayar", 300f, 716f, 19f, android.graphics.Color.rgb(224,49,49), true)
    txt("$unpaid Warga", 455f, 716f, 18f, android.graphics.Color.DKGRAY, false)
    txt("$unpaidPercent%", 575f, 716f, 19f, android.graphics.Color.rgb(18,40,70), true, Paint.Align.RIGHT)

    // Payment detail table is aggregate and always matches the live report.
    rect(35f, 864f, 990f, 1000f, android.graphics.Color.rgb(247,252,249), 0f)
    rect(35f, 946f, 990f, 1000f, android.graphics.Color.rgb(229,247,237), 0f)
    for (x in listOf(113f, 337f, 618f, 810f)) line(x, 864f, x, 1000f)
    for (y in listOf(903f, 946f, 1000f)) line(35f, y, 990f, y)
    val dark = android.graphics.Color.rgb(18,40,70)
    txt("1", 74f, 930f, 18f, dark, false, Paint.Align.CENTER)
    txt("Sudah Bayar", 225f, 930f, 17f, dark, false, Paint.Align.CENTER)
    txt(paid.toString(), 478f, 930f, 18f, dark, false, Paint.Align.CENTER)
    txt(rupiah(paidAmount), 715f, 930f, 17f, dark, false, Paint.Align.CENTER)
    txt("$paidPercent%", 900f, 930f, 17f, dark, false, Paint.Align.CENTER)
    txt("2", 74f, 972f, 18f, dark, false, Paint.Align.CENTER)
    txt("Belum Bayar", 225f, 972f, 17f, dark, false, Paint.Align.CENTER)
    txt(unpaid.toString(), 478f, 972f, 18f, dark, false, Paint.Align.CENTER)
    txt(rupiah(unpaidAmount), 715f, 972f, 17f, dark, false, Paint.Align.CENTER)
    txt("$unpaidPercent%", 900f, 972f, 17f, dark, false, Paint.Align.CENTER)
    txt("Total", 225f, 992f, 18f, dark, true, Paint.Align.CENTER)
    txt(residents.size.toString(), 478f, 992f, 18f, dark, true, Paint.Align.CENTER)
    txt(rupiah(due), 715f, 992f, 17f, dark, true, Paint.Align.CENTER)
    txt("100%", 900f, 992f, 17f, dark, true, Paint.Align.CENTER)

    // Dynamic notes and report date.
    rect(115f, 1039f, 670f, 1140f, android.graphics.Color.WHITE, 2f)
    val today = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(Date())
    txt("Laporan ini merupakan rekapitulasi pembayaran iuran sampah RT 01", 150f, 1068f, 13f, dark)
    txt("untuk periode $month.", 150f, 1090f, 13f, dark)
    txt("Mari bersama-sama membayar iuran tepat waktu demi lingkungan yang bersih,", 150f, 1113f, 13f, dark)
    txt("sehat, dan nyaman.", 150f, 1134f, 13f, dark)
    txt("Terima kasih atas partisipasi seluruh warga.", 150f, 1157f, 13f, dark)
    txt("Pangkalan Kerinci, $today", 844f, 1042f, 13f, dark, false, Paint.Align.CENTER)
}

private fun shareReportImage(context: Context, month: String, monthKeyValue: String, residents: List<Resident>, fee: Int) {
    val w = 1024; val h = 1536
    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    drawReportCanvas(context, Canvas(b), w, h, month, monthKeyValue, residents, fee)
    val file = File(context.cacheDir, "laporan_rt01_${monthKeyValue}.png")
    file.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
    val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
    shareToWhatsApp(context, uri, "image/png", "Bagikan laporan")
}

private fun shareToWhatsApp(context: Context, uri: Uri, mimeType: String, chooserTitle: String) {
    val send = Intent(Intent.ACTION_SEND).apply { type = mimeType; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    val pm = context.packageManager
    val whatsapp = Intent(send).apply { setPackage("com.whatsapp") }
    val business = Intent(send).apply { setPackage("com.whatsapp.w4b") }
    when {
        whatsapp.resolveActivity(pm) != null -> context.startActivity(whatsapp)
        business.resolveActivity(pm) != null -> context.startActivity(business)
        else -> context.startActivity(Intent.createChooser(send, chooserTitle))
    }
}

private fun exportReportPdf(context: Context, month: String, monthKeyValue: String, residents: List<Resident>, fee: Int) {
    val document = PdfDocument(); val w = 1024; val h = 1536
    val pageInfo = PdfDocument.PageInfo.Builder(1024, 1536, 1).create(); val page = document.startPage(pageInfo)
    val canvas = page.canvas; drawReportCanvas(context, canvas, w, h, month, monthKeyValue, residents, fee)
    document.finishPage(page)
    val file = File(context.cacheDir, "laporan_rt01_${monthKeyValue}.pdf")
    file.outputStream().use { document.writeTo(it) }; document.close()
    val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Export PDF"))
}

@Composable private fun MoreScreen(residents: List<Resident>, fee: Int, onFee: () -> Unit, onPassword: () -> Unit, onBackup: () -> Unit, onReminder: () -> Unit, onAbout: () -> Unit, logout: () -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); MoreItem("💰", "Pengaturan Iuran", "Nominal saat ini ${rupiah(fee)}", onFee); MoreItem("🔐", "Akun Admin", "Ubah password admin", onPassword); MoreItem("💾", "Backup & Restore", "Simpan atau pulihkan data", onBackup); MoreItem("🔔", "Pengingat Pembayaran", "${residents.count { (it.payments[monthKey(Calendar.getInstance())] ?: 0) < fee }} warga belum membayar", onReminder); MoreItem("ⓘ", "Tentang Aplikasi", "Versi 1.0.0", onAbout); Button(onClick = logout, Modifier.fillMaxWidth().padding(16.dp).height(52.dp), colors = ButtonDefaults.buttonColors(Red), shape = RoundedCornerShape(13.dp)) { Text("LOGOUT", fontWeight = FontWeight.Bold, fontSize = 16.sp) } } }

@Composable private fun MoreItem(icon: String, title: String, subtitle: String, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(17.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(LightGreen), contentAlignment = Alignment.Center) { Text(icon, fontSize = 25.sp) }; Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp); Text(subtitle, color = Muted, fontSize = 12.sp) }; Text("›", fontSize = 28.sp, color = Muted) } } }

@Composable private fun FeeSettings(fee: Int, onSave: (Int) -> Unit) { var value by remember { mutableStateOf(fee.toString()) }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Pengaturan Iuran") ; Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text("Nominal Iuran per Bulan", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("Nominal") }, prefix = { Text("Rp ") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Spacer(Modifier.height(16.dp)); Button(onClick = { onSave(value.toIntOrNull()?.coerceAtLeast(0) ?: fee) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Simpan") } } } } }

@Composable private fun PasswordSettings(store: AppStore, onBack: () -> Unit) { var old by remember { mutableStateOf("") }; var newP by remember { mutableStateOf("") }; var confirm by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.login_header_final); ScreenTop("Akun Admin", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { PasswordField("Password Lama", old) { old = it }; Spacer(Modifier.height(10.dp)); PasswordField("Password Baru", newP) { newP = it }; Spacer(Modifier.height(10.dp)); PasswordField("Konfirmasi Password", confirm) { confirm = it }; if (msg.isNotBlank()) Text(msg, color = if (msg == "Password berhasil diubah") Green else Red, fontSize = 12.sp); Spacer(Modifier.height(14.dp)); Button(onClick = { msg = when { old != store.password -> "Password lama salah"; newP.isBlank() || newP != confirm -> "Konfirmasi password tidak sama"; else -> { store.password = newP; if (store.rememberMe) store.rememberedPass = newP; "Password berhasil diubah" } } }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("SIMPAN") } } } } }

@Composable private fun PasswordField(label: String, value: String, onValue: (String) -> Unit) { OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(11.dp)) }

@Composable private fun BackupRestore(context: Context, store: AppStore, onRestored: () -> Unit, onBack: () -> Unit) { val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> uri?.let { context.contentResolver.openOutputStream(it)?.use { out -> out.write(store.exportJson().toByteArray()) } } }; val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { val raw = context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }; if (raw != null && store.importJson(raw)) onRestored() } }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Backup & Restore", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Kelola data aplikasi", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(14.dp)); Button(onClick = { create.launch("backup_iuran_sampah_rt01.json") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Backup Data") }; Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = { open.launch(arrayOf("application/json", "text/plain")) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("Restore Data") } } } } }

@Composable private fun ReminderScreen(residents: List<Resident>, fee: Int, onBack: () -> Unit, onOpen: () -> Unit) { val count = residents.count { (it.payments[monthKey(Calendar.getInstance())] ?: 0) < fee }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Pengingat Pembayaran", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("🔔", fontSize = 60.sp); Text("$count warga belum membayar", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center); Spacer(Modifier.height(12.dp)); Button(onClick = onOpen, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Lihat di Pembayaran") } } } } }

@Composable private fun AboutScreen(onBack: () -> Unit) { Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Tentang Aplikasi", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("Iuran Sampah RT 01", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen); Text("Versi 1.0.0", color = Muted); Spacer(Modifier.height(12.dp)); Text("Aplikasi pencatatan iuran sampah dan laporan keuangan warga.", textAlign = TextAlign.Center, color = Muted) } } } }

@Composable private fun EmptyState(title: String, subtitle: String) { Column(Modifier.fillMaxWidth().padding(35.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)) } }

@Composable
private fun BackOnly(onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text("‹", fontSize = 34.sp, modifier = Modifier.size(42.dp).clickable { onBack() }, textAlign = TextAlign.Center, color = Ink)
    }
}

@Composable private fun ScreenTop(title: String, back: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { if (back != null) Text("‹", fontSize = 34.sp, modifier = Modifier.size(38.dp).clickable { back() }, textAlign = TextAlign.Center) else Spacer(Modifier.width(38.dp)); Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold) ; Spacer(Modifier.width(38.dp)) } }

@Composable private fun IconCircle(label: String, onClick: () -> Unit, bg: Color = LightGreen, fg: Color = Green) { Box(Modifier.size(38.dp).clip(CircleShape).background(bg).clickable { onClick() }, contentAlignment = Alignment.Center) { Text(label, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }

@Composable private fun BottomNav(current: Tab, onSelect: (Tab) -> Unit) { NavigationBar(containerColor = Color.White) { listOf(Tab.DASHBOARD to ("⌂" to "Dashboard"), Tab.WARGA to ("♙" to "Warga"), Tab.BAYAR to ("▣" to "Bayar"), Tab.LAPORAN to ("▤" to "Laporan"), Tab.LAINNYA to ("⋯" to "Lainnya")).forEach { (tab, pair) -> NavigationBarItem(selected = current == tab, onClick = { onSelect(tab) }, icon = { Text(pair.first, fontSize = 21.sp, color = if (current == tab) Green else Muted) }, label = { Text(pair.second, fontSize = 9.sp) }) } } }
