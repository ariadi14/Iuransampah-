package com.rt01.kutipansampah

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF087F5B)
private val DarkGreen = Color(0xFF14532D)
private val LightGreen = Color(0xFFEAF8F2)
private val PaleGreen = Color(0xFFF4FBF7)
private val Orange = Color(0xFFF59F00)
private val Red = Color(0xFFE03131)
private val Blue = Color(0xFF1971C2)
private val Purple = Color(0xFF6F42C1)
private val Ink = Color(0xFF18201C)
private val Muted = Color(0xFF718078)

private fun rupiah(v: Int): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }.format(v)
private fun monthKey(c: Calendar): String = SimpleDateFormat("yyyy-MM", Locale.US).format(c.time)
private fun monthLabel(c: Calendar): String = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(c.time).replaceFirstChar { it.uppercase() }
private fun todayLabel(): String = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(Date()).replaceFirstChar { it.uppercase() }

private data class Resident(
    val id: Long,
    val name: String,
    val house: String,
    val phone: String,
    val note: String,
    val payments: Map<String, Int> = emptyMap()
)

private enum class Tab { DASHBOARD, WARGA, BAYAR, LAPORAN, LAINNYA }
private enum class Status { LUNAS, KURANG, BELUM }
private enum class Screen { HOME, DETAIL, ADD, EDIT, PAYMENT, EDIT_PAYMENT, PASSWORD, IURAN, BACKUP, REMINDER, ABOUT }

private class AppStore(context: Context) {
    private val p = context.getSharedPreferences("rt01_store", Context.MODE_PRIVATE)
    var username: String
        get() = p.getString("username", "admin") ?: "admin"
        set(v) = p.edit().putString("username", v).apply()
    var password: String
        get() = p.getString("password", "admin123") ?: "admin123"
        set(v) = p.edit().putString("password", v).apply()
    var rememberedUser: String
        get() = p.getString("remember_user", "") ?: ""
        set(v) = p.edit().putString("remember_user", v).apply()
    var rememberedPass: String
        get() = p.getString("remember_pass", "") ?: ""
        set(v) = p.edit().putString("remember_pass", v).apply()
    var rememberMe: Boolean
        get() = p.getBoolean("remember_me", false)
        set(v) = p.edit().putBoolean("remember_me", v).apply()
    var fee: Int
        get() = p.getInt("fee", 10000)
        set(v) = p.edit().putInt("fee", v).apply()
    var residents: List<Resident>
        get() = decodeResidents(p.getString("residents", "[]") ?: "[]")
        set(v) = p.edit().putString("residents", encodeResidents(v)).apply()

    private fun encodeResidents(list: List<Resident>): String = JSONArray().apply {
        list.forEach { r ->
            put(JSONObject().apply {
                put("id", r.id); put("name", r.name); put("house", r.house); put("phone", r.phone); put("note", r.note)
                put("payments", JSONObject().apply { r.payments.forEach { (k, v) -> put(k, v) } })
            })
        }
    }.toString()

    private fun decodeResidents(raw: String): List<Resident> = runCatching {
        val a = JSONArray(raw); buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val po = o.optJSONObject("payments") ?: JSONObject(); val map = mutableMapOf<String, Int>()
                po.keys().forEach { k -> map[k] = po.optInt(k, 0) }
                add(Resident(o.optLong("id", System.currentTimeMillis() + i), o.optString("name"), o.optString("house"), o.optString("phone"), o.optString("note"), map))
            }
        }
    }.getOrDefault(emptyList())

    fun exportJson(): String = JSONObject().apply { put("fee", fee); put("username", username); put("residents", JSONArray(encodeResidents(residents)).let { it }) }.toString(2)
    fun importJson(raw: String): Boolean = runCatching {
        val o = JSONObject(raw); fee = o.optInt("fee", fee); username = o.optString("username", username); residents = decodeResidents(o.optJSONArray("residents")?.toString() ?: "[]"); true
    }.getOrDefault(false)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KutipanApp(this) }
    }
}

@Composable
private fun KutipanApp(context: Context) {
    val store = remember { AppStore(context) }
    var loggedIn by remember { mutableStateOf(store.rememberMe && store.rememberedUser.isNotBlank() && store.rememberedPass.isNotBlank()) }
    if (!loggedIn) LoginScreen(store) { loggedIn = true } else MainShell(context, store) { loggedIn = false }
}

@Composable
private fun LoginScreen(store: AppStore, onLogin: () -> Unit) {
    var user by remember { mutableStateOf(if (store.rememberMe) store.rememberedUser else "") }
    var pass by remember { mutableStateOf(if (store.rememberMe) store.rememberedPass else "") }
    var rememberMe by remember { mutableStateOf(store.rememberMe) }
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) {
        Image(painterResource(R.drawable.login_header_final), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop)
        Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(Color.White)) {
            Column(Modifier.padding(18.dp)) {
                OutlinedTextField(user, { user = it; error = false }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(pass, { pass = it; error = false }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(rememberMe, { rememberMe = it }); Text("Ingat saya", color = Muted, fontSize = 15.sp)
                }
                if (error) Text("Username atau password salah.", color = Red, fontSize = 12.sp)
                Button(onClick = {
                    if (user == store.username && pass == store.password) {
                        store.rememberMe = rememberMe
                        if (rememberMe) { store.rememberedUser = user; store.rememberedPass = pass } else { store.rememberedUser = ""; store.rememberedPass = "" }
                        onLogin()
                    } else error = true
                }, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(14.dp)) { Text("LOGIN", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
            }
        }
        Text("“Bersama kita jaga lingkungan yang bersih”", Modifier.fillMaxWidth().padding(18.dp), textAlign = TextAlign.Center, color = DarkGreen, fontSize = 14.sp)
    }
}

@Composable
private fun MainShell(context: Context, store: AppStore, logout: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var paymentMonth by remember { mutableStateOf(Calendar.getInstance()) }
    var filter by remember { mutableStateOf<Status?>(null) }
    var residents by remember { mutableStateOf(store.residents) }
    var fee by remember { mutableStateOf(store.fee) }

    fun saveResidents(v: List<Resident>) { residents = v; store.residents = v }
    fun go(t: Tab) { tab = t; screen = Screen.HOME; selectedId = null }
    fun selected(): Resident? = residents.firstOrNull { it.id == selectedId }

    when (screen) {
        Screen.DETAIL -> selected()?.let { DetailResident(it, fee, { screen = Screen.HOME }, { screen = Screen.EDIT }, { saveResidents(residents.filterNot { r -> r.id == it.id }); screen = Screen.HOME }) } ?: run { screen = Screen.HOME }
        Screen.ADD -> ResidentForm(null, { screen = Screen.HOME }, { name, house, phone, note -> saveResidents(residents + Resident(System.currentTimeMillis(), name, house, phone, note)); screen = Screen.HOME })
        Screen.EDIT -> selected()?.let { r -> ResidentForm(r, { screen = Screen.DETAIL }, { name, house, phone, note -> saveResidents(residents.map { x -> if (x.id == r.id) x.copy(name = name, house = house, phone = phone, note = note) else x }); screen = Screen.DETAIL }) } ?: run { screen = Screen.HOME }
        Screen.PAYMENT, Screen.EDIT_PAYMENT -> selected()?.let { r -> PaymentForm(r, paymentMonth, fee, screen == Screen.EDIT_PAYMENT, { screen = Screen.HOME }, { amount ->
            val map = r.payments.toMutableMap(); map[monthKey(paymentMonth)] = amount; saveResidents(residents.map { x -> if (x.id == r.id) x.copy(payments = map) else x }); screen = Screen.HOME
        }, { screen = Screen.EDIT_PAYMENT }) } ?: run { screen = Screen.HOME }
        Screen.PASSWORD -> PasswordSettings(store) { screen = Screen.HOME }
        Screen.IURAN -> FeeSettings(fee) { fee = it; store.fee = it; screen = Screen.HOME }
        Screen.BACKUP -> BackupRestore(context, store, { residents = store.residents; fee = store.fee; screen = Screen.HOME }, { screen = Screen.HOME })
        Screen.REMINDER -> ReminderScreen(residents, fee, { screen = Screen.HOME }, { tab = Tab.BAYAR; filter = Status.BELUM; screen = Screen.HOME })
        Screen.ABOUT -> AboutScreen { screen = Screen.HOME }
        Screen.HOME -> Scaffold(bottomBar = { BottomNav(tab) { go(it) } }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad).background(PaleGreen)) {
                when (tab) {
                    Tab.DASHBOARD -> Dashboard(residents, fee, { go(Tab.WARGA) }, { filter = it; go(Tab.BAYAR) }, { go(Tab.LAPORAN) }, { selectedId = it; screen = Screen.DETAIL })
                    Tab.WARGA -> ResidentsScreen(residents, { selectedId = it; screen = Screen.DETAIL }, { screen = Screen.ADD })
                    Tab.BAYAR -> PaymentOverview(residents, fee, paymentMonth, filter, { filter = it }, { selectedId = it; screen = Screen.PAYMENT })
                    Tab.LAPORAN -> ReportScreen(residents, fee, paymentMonth, context, { paymentMonth = it })
                    Tab.LAINNYA -> MoreScreen(residents, fee, { screen = Screen.IURAN }, { screen = Screen.PASSWORD }, { screen = Screen.BACKUP }, { screen = Screen.REMINDER }, { screen = Screen.ABOUT }, logout)
                }
            }
        }
    }
}

@Composable
private fun Hero(resId: Int) { Image(painterResource(resId), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop) }

@Composable
private fun Dashboard(residents: List<Resident>, fee: Int, onWarga: () -> Unit, onBayar: (Status) -> Unit, onReport: () -> Unit, onDetail: (Resident) -> Unit) {
    val now = Calendar.getInstance(); val key = monthKey(now); val paid = residents.count { (it.payments[key] ?: 0) >= fee }; val unpaid = residents.count { (it.payments[key] ?: 0) == 0 }; val income = residents.sumOf { it.payments[key] ?: 0 }
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date())) }
    var date by remember { mutableStateOf(todayLabel()) }
    LaunchedEffect(Unit) { while (true) { time = SimpleDateFormat("HH:mm:ss", Locale("id", "ID")).format(Date()); date = todayLabel(); kotlinx.coroutines.delay(1000) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero(R.drawable.dashboard_header_final)
        Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(Color.White)) { Column(Modifier.fillMaxWidth().padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(time, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen); Text(date, fontSize = 15.sp, color = Muted, fontWeight = FontWeight.SemiBold) } }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp).clickable { onReport() }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(Color(0xFF3FBE78))) { Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) { IconCircle("▤", {}, Color.White.copy(.35f), Color.White); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Laporan", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White); Text("Total Pemasukan dari Warga", color = Color.White); Text(rupiah(income), fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }; Text("›", fontSize = 38.sp, color = Color.White) } }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("✓", "Sudah Bayar", paid.toString(), Green, Modifier.weight(1f)) { onBayar(Status.LUNAS) }; StatCard("👥", "Total Warga", residents.size.toString(), Blue, Modifier.weight(1f)) { onWarga() }; StatCard("×", "Belum Bayar", unpaid.toString(), Red, Modifier.weight(1f)) { onBayar(Status.BELUM) } }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) { Column(Modifier.padding(vertical = 8.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text("Daftar Terbaru", Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp); Text("Lihat Semua", color = Green, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onWarga() }) }; residents.sortedBy { it.name }.take(5).forEach { ResidentRow(it, { onDetail(it) }, showStatus = false, index = null) } } }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable private fun StatCard(icon: String, label: String, value: String, color: Color, modifier: Modifier, onClick: () -> Unit) { Card(modifier.clickable { onClick() }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(44.dp).clip(CircleShape).background(color.copy(.12f)), contentAlignment = Alignment.Center) { Text(icon, fontSize = 21.sp, color = color, fontWeight = FontWeight.Bold) }; Text(label, fontSize = 10.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold); Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = color); Text("Warga", fontSize = 10.sp, color = Muted) } } }

@Composable
private fun ResidentsScreen(residents: List<Resident>, onResident: (Resident) -> Unit, onAdd: () -> Unit) {
    var query by remember { mutableStateOf("") }; val filtered = residents.filter { it.name.contains(query, true) || it.house.contains(query, true) }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero(R.drawable.warga_header_final)
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(query, { query = it }, placeholder = { Text("Cari nama atau nomor rumah...") }, leadingIcon = { Text("⌕", fontSize = 23.sp) }, modifier = Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(14.dp)); Spacer(Modifier.width(8.dp)); Button(onClick = onAdd, Modifier.height(56.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(14.dp)) { Text("+\nWarga", textAlign = TextAlign.Center, fontWeight = FontWeight.Bold) } }
        if (filtered.isEmpty()) EmptyState("Belum ada data warga", "Tambahkan warga melalui tombol + Warga")
        else filtered.forEachIndexed { i, r -> ResidentRow(r, onResident, showStatus = false, index = i + 1) }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun ResidentRow(r: Resident, onClick: (Resident) -> Unit, showStatus: Boolean, index: Int?) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clickable { onClick(r) }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(Color.White)) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            if (index != null) { Box(Modifier.size(32.dp).clip(CircleShape).background(LightGreen), contentAlignment = Alignment.Center) { Text(index.toString(), color = Green, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(9.dp)) }
            Box(Modifier.size(45.dp).clip(CircleShape).background(LightGreen), contentAlignment = Alignment.Center) { Text("●", color = Green, fontSize = 25.sp) }; Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.Bold, color = Ink); Text(r.house, fontSize = 12.sp, color = Muted); if (r.phone.isNotBlank()) Text(r.phone, fontSize = 11.sp, color = Muted) }
            if (showStatus) { val amount = r.payments[monthKey(Calendar.getInstance())] ?: 0; val status = if (amount >= 10000) Status.LUNAS else if (amount > 0) Status.KURANG else Status.BELUM; val c = if (status == Status.LUNAS) Green else if (status == Status.KURANG) Orange else Red; Surface(color = c.copy(.13f), shape = RoundedCornerShape(10.dp)) { Text(if (status == Status.LUNAS) "Sudah Bayar" else if (status == Status.KURANG) "Kurang Bayar" else "Belum Bayar", color = c, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(7.dp)) } }
            Text("›", fontSize = 28.sp, color = Muted)
        }
    }
}

@Composable
private fun ResidentForm(existing: Resident?, onBack: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }; var house by remember { mutableStateOf(existing?.house ?: "") }; var phone by remember { mutableStateOf(existing?.phone ?: "") }; var note by remember { mutableStateOf(existing?.note ?: "") }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.warga_header_final); ScreenTop(if (existing == null) "Tambah Warga" else "Edit Warga", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text(if (existing == null) "Tambah Data Warga Baru" else "Edit Data Warga", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(14.dp)); OutlinedTextField(name, { name = it }, label = { Text("Nama Warga *") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(10.dp)); OutlinedTextField(house, { house = it }, label = { Text("Nomor Rumah *") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(10.dp)); OutlinedTextField(phone, { phone = it }, label = { Text("Nomor HP") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(10.dp)); OutlinedTextField(note, { note = it }, label = { Text("Keterangan") }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(12.dp)); Spacer(Modifier.height(16.dp)); Row { OutlinedButton(onClick = onBack, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Batal") }; Spacer(Modifier.width(8.dp)); Button(onClick = { if (name.isNotBlank() && house.isNotBlank()) onSave(name.trim(), house.trim(), phone.trim(), note.trim()) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Simpan", fontWeight = FontWeight.Bold) } } } } }
}

@Composable
private fun DetailResident(r: Resident, fee: Int, onBack: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.warga_header_final); ScreenTop("Detail Warga", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(62.dp).clip(CircleShape).background(Color(0xFFE8F3FF)), contentAlignment = Alignment.Center) { Text("●", color = Blue, fontSize = 35.sp) }; Spacer(Modifier.width(12.dp)); Column { Text(r.name, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Text(r.house, color = Muted); Text(if (r.phone.isBlank()) "Nomor HP belum diisi" else r.phone, color = Muted, fontSize = 12.sp) } }; Spacer(Modifier.height(14.dp)); Row { Button(onClick = onEdit, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(11.dp)) { Text("Edit") }; Spacer(Modifier.width(8.dp)); Button(onClick = { confirm = true }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Red), shape = RoundedCornerShape(11.dp)) { Text("Hapus") } }; Spacer(Modifier.height(20.dp)); Text("Riwayat Pembayaran", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold); val c = Calendar.getInstance(); repeat(6) { idx -> val m = (c.clone() as Calendar).apply { add(Calendar.MONTH, -idx) }; val amount = r.payments[monthKey(m)] ?: 0; val status = if (amount >= fee) Status.LUNAS else if (amount > 0) Status.KURANG else Status.BELUM; val color = if (status == Status.LUNAS) Green else if (status == Status.KURANG) Orange else Red; Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(11.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(monthLabel(m), Modifier.weight(1f)); Text(if (status == Status.LUNAS) "Sudah Bayar" else if (status == Status.KURANG) "Kurang Bayar" else "Belum Bayar", color = color, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.width(8.dp)); Text(rupiah(amount), fontWeight = FontWeight.Bold, fontSize = 11.sp) } } } } } }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Hapus warga?") }, text = { Text("Data ${r.name} akan dihapus dari daftar warga.") }, confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Hapus", color = Red) } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } })
}

@Composable
private fun PaymentOverview(residents: List<Resident>, fee: Int, month: Calendar, filter: Status?, onFilter: (Status?) -> Unit, onPay: (Resident) -> Unit) {
    val key = monthKey(month); val filtered = residents.filter { r -> val a = r.payments[key] ?: 0; when (filter) { Status.LUNAS -> a >= fee; Status.KURANG -> a in 1 until fee; Status.BELUM -> a == 0; null -> true } }.sortedBy { it.name }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.payment_header_final); Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) { FilterButton("Semua", filter == null, null, onFilter); FilterButton("Sudah Bayar", filter == Status.LUNAS, Status.LUNAS, onFilter); FilterButton("Belum Bayar", filter == Status.BELUM, Status.BELUM, onFilter) }; Button(onClick = { residents.firstOrNull()?.let(onPay) }, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).height(50.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(13.dp)) { Text("CATAT PEMBAYARAN", fontWeight = FontWeight.Bold) }; filtered.forEach { r -> ResidentPaymentRow(r, fee, key) { onPay(it) } }; if (filtered.isEmpty()) EmptyState(if (residents.isEmpty()) "Belum ada data warga" else "Tidak ada warga dengan status ini", "Tambahkan warga atau ubah filter") }
}

@Composable private fun FilterButton(label: String, selected: Boolean, status: Status?, onClick: (Status?) -> Unit) { Button(onClick = { onClick(status) }, colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFFE7D8F7) else Color.White, contentColor = Ink), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp)) { Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) } }

@Composable private fun ResidentPaymentRow(r: Resident, fee: Int, key: String, onClick: (Resident) -> Unit) { val amount = r.payments[key] ?: 0; val status = if (amount >= fee) Status.LUNAS else if (amount > 0) Status.KURANG else Status.BELUM; val c = if (status == Status.LUNAS) Green else if (status == Status.KURANG) Orange else Red; Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clickable { onClick(r) }, colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(46.dp).clip(CircleShape).background(c.copy(.12f)), contentAlignment = Alignment.Center) { Text("●", color = c, fontSize = 25.sp) }; Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.Bold); Text(r.house, color = Muted, fontSize = 12.sp); Text(if (status == Status.LUNAS) "Sudah Bayar" else if (status == Status.KURANG) "Kurang Bayar" else "Belum Bayar", color = c, fontWeight = FontWeight.Bold, fontSize = 11.sp) }; Text("›", fontSize = 28.sp, color = Muted) } } }

@Composable
private fun PaymentForm(r: Resident, monthStart: Calendar, fee: Int, editing: Boolean, onBack: () -> Unit, onSave: (Int) -> Unit, onEdit: () -> Unit) {
    var month by remember { mutableStateOf((monthStart.clone() as Calendar)) }; val key = monthKey(month); var amount by remember { mutableStateOf((r.payments[key] ?: 0).toString()) }; var status by remember { mutableStateOf(if ((r.payments[key] ?: 0) >= fee) Status.LUNAS else if ((r.payments[key] ?: 0) > 0) Status.KURANG else Status.BELUM) }
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.payment_header_final); ScreenTop(if (editing) "Edit Pembayaran" else "Pembayaran", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text(r.name, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Text(r.house, color = Muted); Spacer(Modifier.height(16.dp)); Text("Bulan", fontWeight = FontWeight.Bold); Row(verticalAlignment = Alignment.CenterVertically) { IconCircle("‹", { val c = (month.clone() as Calendar); c.add(Calendar.MONTH, -1); month = c }, LightGreen, Green); Text(monthLabel(month), Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold); IconCircle("›", { val c = (month.clone() as Calendar); c.add(Calendar.MONTH, 1); month = c }, LightGreen, Green) }; Spacer(Modifier.height(14.dp)); Text("Nominal Iuran", fontWeight = FontWeight.Bold); OutlinedTextField(rupiah(fee), {}, Modifier.fillMaxWidth(), enabled = false, shape = RoundedCornerShape(11.dp)); Spacer(Modifier.height(12.dp)); Text("Status Pembayaran", fontWeight = FontWeight.Bold); Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { StatusChoice("Sudah Bayar", Status.LUNAS, status, Modifier.weight(1f)) { status = it; amount = if (it == Status.LUNAS) fee.toString() else if (it == Status.BELUM) "0" else amount }; StatusChoice("Kurang Bayar", Status.KURANG, status, Modifier.weight(1f)) { status = it }; StatusChoice("Belum Bayar", Status.BELUM, status, Modifier.weight(1f)) { status = it; amount = "0" } }; OutlinedTextField(amount, { amount = it.filter(Char::isDigit); status = when { (it.toIntOrNull() ?: 0) >= fee -> Status.LUNAS; (it.toIntOrNull() ?: 0) > 0 -> Status.KURANG; else -> Status.BELUM } }, label = { Text("Jumlah Bayar") }, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(11.dp)); Spacer(Modifier.height(18.dp)); Row { OutlinedButton(onClick = onBack, Modifier.weight(1f), shape = RoundedCornerShape(11.dp)) { Text("Batal") }; Spacer(Modifier.width(6.dp)); if (editing || status == Status.LUNAS) { OutlinedButton(onClick = onEdit, Modifier.weight(1f), shape = RoundedCornerShape(11.dp)) { Text("Edit Pembayaran", fontSize = 9.sp) }; Spacer(Modifier.width(6.dp)) }; Button(onClick = { onSave(amount.toIntOrNull()?.coerceIn(0, fee) ?: 0) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(11.dp)) { Text("Simpan", fontWeight = FontWeight.Bold) } } } } }
}

@Composable private fun StatusChoice(label: String, value: Status, selected: Status, modifier: Modifier, onClick: (Status) -> Unit) { val c = if (value == Status.LUNAS) Green else if (value == Status.KURANG) Orange else Red; OutlinedButton(onClick = { onClick(value) }, modifier = modifier, colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selected == value) c.copy(.12f) else Color.Transparent, contentColor = c), border = ButtonDefaults.outlinedButtonBorder, shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(4.dp)) { Text(label, fontSize = 9.sp, textAlign = TextAlign.Center) } }

@Composable
private fun ReportScreen(residents: List<Resident>, fee: Int, monthStart: Calendar, context: Context, onMonth: (Calendar) -> Unit) {
    var month by remember { mutableStateOf(monthStart.clone() as Calendar) }; val key = monthKey(month); val due = residents.size * fee; val income = residents.sumOf { it.payments[key] ?: 0 }; val progress = if (due == 0) 0 else (income * 100 / due).coerceIn(0, 100)
    Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.report_header_final); Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { IconCircle("‹", { val c = month.clone() as Calendar; c.add(Calendar.MONTH, -1); month = c; onMonth(c) }, LightGreen, Green); Text(monthLabel(month), Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); IconCircle("›", { val c = month.clone() as Calendar; c.add(Calendar.MONTH, 1); month = c; onMonth(c) }, LightGreen, Green) }
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp)) { Text("Ringkasan Keuangan", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(10.dp)); ReportLine("Total Seharusnya", rupiah(due), Ink); ReportLine("Total Diterima", rupiah(income), Green); ReportLine("Sisa Tagihan", rupiah(due - income), Red); HorizontalDivider(Modifier.padding(vertical = 12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(110.dp).clip(CircleShape).background(Color(0xFFE7ECEF)), contentAlignment = Alignment.Center) { Box(Modifier.size(80.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) { Text("$progress%", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen) } }; Spacer(Modifier.width(18.dp)); Column { Text("Realisasi Pembayaran", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp); Text("Berdasarkan pembayaran bulan ${monthLabel(month)}", color = Muted, fontSize = 12.sp) } } } }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(LightGreen), shape = RoundedCornerShape(18.dp)) { Text("“Pembayaran iuran mendukung lingkungan yang lebih bersih dan sehat.”", Modifier.padding(18.dp), color = DarkGreen, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { shareReportImage(context, monthLabel(month), monthKey(month), residents, fee) }, Modifier.weight(1f).height(58.dp), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(13.dp)) { Text("Bagikan Laporan", textAlign = TextAlign.Center) }; OutlinedButton(onClick = { shareReportImage(context, monthLabel(month), monthKey(month), residents, fee) }, Modifier.weight(1f).height(58.dp), shape = RoundedCornerShape(13.dp)) { Text("Export PDF", textAlign = TextAlign.Center) } }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable private fun ReportLine(label: String, value: String, color: Color = Ink) { Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) { Text(label, Modifier.weight(1f), color = Muted, fontSize = 14.sp); Text(value, fontWeight = FontWeight.ExtraBold, color = color, fontSize = 15.sp) } }

private fun shareReportImage(context: Context, month: String, monthKeyValue: String, residents: List<Resident>, fee: Int) {
    val w = 1080; val h = 1500; val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b); c.drawColor(android.graphics.Color.rgb(244, 251, 247)); val p = Paint(Paint.ANTI_ALIAS_FLAG); fun txt(s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) { p.color = color; p.textSize = size; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; c.drawText(s, x, y, p) }
    txt("LAPORAN KEUANGAN", 70f, 100f, 58f, android.graphics.Color.rgb(8,127,91), true); txt("Iuran Sampah RT 01", 70f, 160f, 38f, android.graphics.Color.rgb(24,32,28), true); txt("Periode: $month", 70f, 210f, 28f, android.graphics.Color.DKGRAY, false)
    val income = residents.sumOf { it.payments[monthKeyValue] ?: 0 }; val due = residents.size * fee
    txt("Ringkasan Keuangan", 70f, 290f, 36f, android.graphics.Color.rgb(20,83,45), true); txt("Total Seharusnya: ${rupiah(due)}", 80f, 350f, 30f, android.graphics.Color.DKGRAY); txt("Total Diterima: ${rupiah(income)}", 80f, 400f, 30f, android.graphics.Color.rgb(8,127,91), true); txt("Sisa Tagihan: ${rupiah(due-income)}", 80f, 450f, 30f, android.graphics.Color.rgb(224,49,49), true)
    txt("Rincian Pembayaran", 70f, 540f, 36f, android.graphics.Color.rgb(20,83,45), true); var y = 600f; residents.sortedBy { it.name }.forEachIndexed { i, r -> val amount = r.payments.values.firstOrNull() ?: 0; txt("${i+1}. ${r.name}", 75f, y, 27f, android.graphics.Color.DKGRAY, true); txt("${r.house}   ${rupiah(amount)}", 90f, y+38, 24f, android.graphics.Color.GRAY); y += 90f }
    txt("Bersama menjaga lingkungan tetap bersih dan sehat.", 70f, minOf(y + 40, 1400f), 26f, android.graphics.Color.rgb(20,83,45), true)
    val file = File(context.cacheDir, "laporan_rt01.png"); file.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; val uri: Uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file); context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Bagikan laporan"))
}

@Composable private fun MoreScreen(residents: List<Resident>, fee: Int, onFee: () -> Unit, onPassword: () -> Unit, onBackup: () -> Unit, onReminder: () -> Unit, onAbout: () -> Unit, logout: () -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); MoreItem("💰", "Pengaturan Iuran", "Nominal saat ini ${rupiah(fee)}", onFee); MoreItem("🔐", "Akun Admin", "Ubah password admin", onPassword); MoreItem("💾", "Backup & Restore", "Simpan atau pulihkan data", onBackup); MoreItem("🔔", "Pengingat Pembayaran", "${residents.count { (it.payments[monthKey(Calendar.getInstance())] ?: 0) < fee }} warga belum membayar", onReminder); MoreItem("ⓘ", "Tentang Aplikasi", "Versi 1.0.0", onAbout); Button(onClick = logout, Modifier.fillMaxWidth().padding(16.dp).height(52.dp), colors = ButtonDefaults.buttonColors(Red), shape = RoundedCornerShape(13.dp)) { Text("LOGOUT", fontWeight = FontWeight.Bold, fontSize = 16.sp) } } }

@Composable private fun MoreItem(icon: String, title: String, subtitle: String, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(17.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(LightGreen), contentAlignment = Alignment.Center) { Text(icon, fontSize = 25.sp) }; Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp); Text(subtitle, color = Muted, fontSize = 12.sp) }; Text("›", fontSize = 28.sp, color = Muted) } } }

@Composable private fun FeeSettings(fee: Int, onSave: (Int) -> Unit) { var value by remember { mutableStateOf(fee.toString()) }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Pengaturan Iuran") ; Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text("Nominal Iuran per Bulan", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(12.dp)); OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("Nominal") }, prefix = { Text("Rp ") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Spacer(Modifier.height(16.dp)); Button(onClick = { onSave(value.toIntOrNull()?.coerceAtLeast(0) ?: fee) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Simpan") } } } } }

@Composable private fun PasswordSettings(store: AppStore, onBack: () -> Unit) { var old by remember { mutableStateOf("") }; var newP by remember { mutableStateOf("") }; var confirm by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.login_header_final); ScreenTop("Akun Admin", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) { PasswordField("Password Lama", old) { old = it }; Spacer(Modifier.height(10.dp)); PasswordField("Password Baru", newP) { newP = it }; Spacer(Modifier.height(10.dp)); PasswordField("Konfirmasi Password", confirm) { confirm = it }; if (msg.isNotBlank()) Text(msg, color = if (msg == "Password berhasil diubah") Green else Red, fontSize = 12.sp); Spacer(Modifier.height(14.dp)); Button(onClick = { msg = when { old != store.password -> "Password lama salah"; newP.isBlank() || newP != confirm -> "Konfirmasi password tidak sama"; else -> { store.password = newP; if (store.rememberMe) store.rememberedPass = newP; "Password berhasil diubah" } } }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("SIMPAN") } } } } }

@Composable private fun PasswordField(label: String, value: String, onValue: (String) -> Unit) { OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(11.dp)) }

@Composable private fun BackupRestore(context: Context, store: AppStore, onRestored: () -> Unit, onBack: () -> Unit) { val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> uri?.let { context.contentResolver.openOutputStream(it)?.use { out -> out.write(store.exportJson().toByteArray()) } } }; val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { val raw = context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }; if (raw != null && store.importJson(raw)) onRestored() } }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Backup & Restore", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Kelola data aplikasi", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(14.dp)); Button(onClick = { create.launch("backup_iuran_sampah_rt01.json") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Backup Data") }; Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = { open.launch(arrayOf("application/json", "text/plain")) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Text("Restore Data") } } } } }

@Composable private fun ReminderScreen(residents: List<Resident>, fee: Int, onBack: () -> Unit, onOpen: () -> Unit) { val count = residents.count { (it.payments[monthKey(Calendar.getInstance())] ?: 0) < fee }; Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Pengingat Pembayaran", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("🔔", fontSize = 60.sp); Text("$count warga belum membayar", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center); Spacer(Modifier.height(12.dp)); Button(onClick = onOpen, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Green), shape = RoundedCornerShape(12.dp)) { Text("Lihat di Pembayaran") } } } } }

@Composable private fun AboutScreen(onBack: () -> Unit) { Column(Modifier.fillMaxSize().background(PaleGreen).verticalScroll(rememberScrollState())) { Hero(R.drawable.settings_header_final); ScreenTop("Tentang Aplikasi", onBack); Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("Iuran Sampah RT 01", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = DarkGreen); Text("Versi 1.0.0", color = Muted); Spacer(Modifier.height(12.dp)); Text("Aplikasi pencatatan iuran sampah dan laporan keuangan warga.", textAlign = TextAlign.Center, color = Muted) } } } }

@Composable private fun EmptyState(title: String, subtitle: String) { Column(Modifier.fillMaxWidth().padding(35.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)) } }

@Composable private fun ScreenTop(title: String, back: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { if (back != null) Text("‹", fontSize = 34.sp, modifier = Modifier.size(38.dp).clickable { back() }, textAlign = TextAlign.Center) else Spacer(Modifier.width(38.dp)); Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold) ; Spacer(Modifier.width(38.dp)) } }

@Composable private fun IconCircle(label: String, onClick: () -> Unit, bg: Color = LightGreen, fg: Color = Green) { Box(Modifier.size(38.dp).clip(CircleShape).background(bg).clickable { onClick() }, contentAlignment = Alignment.Center) { Text(label, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold) } }

@Composable private fun BottomNav(current: Tab, onSelect: (Tab) -> Unit) { NavigationBar(containerColor = Color.White) { listOf(Tab.DASHBOARD to ("⌂" to "Dashboard"), Tab.WARGA to ("♙" to "Warga"), Tab.BAYAR to ("▣" to "Bayar"), Tab.LAPORAN to ("▤" to "Laporan"), Tab.LAINNYA to ("⋯" to "Lainnya")).forEach { (tab, pair) -> NavigationBarItem(selected = current == tab, onClick = { onSelect(tab) }, icon = { Text(pair.first, fontSize = 21.sp, color = if (current == tab) Green else Muted) }, label = { Text(pair.second, fontSize = 9.sp) }) } } }
