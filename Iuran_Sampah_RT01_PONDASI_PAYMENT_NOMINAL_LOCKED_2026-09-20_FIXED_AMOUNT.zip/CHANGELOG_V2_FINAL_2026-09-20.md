# Iuran Sampah RT 01 — V2 Final Visual Fix

## Perubahan final 20 September 2026
- Nama aplikasi launcher: **Iuran Sampah**.
- Ikon launcher memakai desain final hijau gelap dengan rumah, tempat sampah/recycle, daun, dan teks **RT 01**.
- Halaman Login: background tetap diarahkan full-height sesuai instruksi final.
- Data Warga: perbaikan ruang teks pencarian/tombol tambah dan sistem avatar huruf 5 variasi visual.
- Pembayaran: nominal default Rp15.000 dan keterangan nominal mengikuti nilai input secara dinamis.
- Halaman Laporan: background atas lama yang sudah disetujui **tidak diubah**; ringkasan dan realisasi diperbarui dengan kartu modern.
- Halaman Laporan tidak menampilkan fitur **Kurang Bayar** pada ringkasan/laporan final.
- Gambar laporan yang dibagikan: renderer baru 1080x1920, data aktual aplikasi, daftar hanya warga **Belum Bayar**, dan daftar kosong bila semua warga sudah membayar.
- Gambar laporan tidak lagi menggunakan `laporan_keuangan_final.png` yang mengandung elemen contoh/blur.
- Tombol Bagikan menggunakan PNG resolusi tinggi dan URI FileProvider read-only untuk WhatsApp/aplikasi berbagi.
- PDF menggunakan layout renderer laporan final yang sama.

## Catatan build
Build lokal tidak dapat dijalankan di lingkungan ini karena Gradle executable/Android SDK tidak tersedia. Source dan resource sudah diperbarui; build tetap perlu dijalankan melalui GitHub Actions project.
