# Kutipan Sampah RT 01

Aplikasi Android untuk pencatatan iuran/kutipan sampah RT 01.

## Tampilan final
Source ini menggunakan tampilan final hijau modern untuk:
- Login
- Dashboard
- Data Warga
- Pencatatan Pembayaran
- Laporan Bulanan
- Detail Warga
- Lainnya
- Pengingat Pembayaran
- Ubah Password

## Build
GitHub Actions tersedia pada `.github/workflows/build-apk.yml` dan menghasilkan APK debug sebagai artifact.

Demo login: `admin` / `admin123`
