# Pengembangan berikutnya

1. Persistensi data warga dan pembayaran ke database lokal.
2. Form tambah/edit warga lengkap.
3. Nominal iuran dapat diatur dari Pengaturan Iuran.
4. Bulan aktif otomatis dan riwayat pembayaran lintas bulan.
5. Export laporan sebagai gambar/PDF.
6. Bagikan kuitansi pembayaran individual.
7. Backup/restore data.
8. Notifikasi pengingat pembayaran.
9. Pengaturan profil RT dan logo.
10. Validasi login dan pengelolaan akun admin yang aman.
